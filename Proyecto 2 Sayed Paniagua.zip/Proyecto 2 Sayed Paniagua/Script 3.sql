SELECT Nombre FROM ELETiendas
GROUP BY Nombre
ORDER BY Nombre;
SELECT SUM (Saldo) FROM ELETiendaProducto AS [Ventas Totales]
SELECT COUNT (NumFactura) FROM ELEFacturaEnc AS [Numero Total de Facturas]