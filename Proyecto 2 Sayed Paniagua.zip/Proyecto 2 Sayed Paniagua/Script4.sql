SELECT Identificacion, Nombre FROM ELEClientes
GROUP BY Identificacion, Nombre
ORDER BY Identificacion;
SELECT SUM (Total) FROM ELEFacturaEnc AS [Total Pagado]
GROUP BY Total;
SELECT COUNT (NumFactura) FROM ELEFacturaEnc AS [Cantidad Comprada]
GROUP BY NumFactura;