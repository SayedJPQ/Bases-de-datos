USE [ElectroStore]
GO
/****** Object:  Table [dbo].[ELECargos]    Script Date: 03/11/2024 01:04:07 a. m. ******/
ALTER TABLE ELECargos NOCHECK CONSTRAINT ALL;
ALTER TABLE ELECategorias NOCHECK CONSTRAINT ALL;
ALTER TABLE ELEClientes NOCHECK CONSTRAINT ALL;
ALTER TABLE ELEEmpleados NOCHECK CONSTRAINT ALL;
ALTER TABLE ELEFacturaEnc NOCHECK CONSTRAINT ALL;
ALTER TABLE ELEFacturasDet NOCHECK CONSTRAINT ALL;
ALTER TABLE ELEMarcas NOCHECK CONSTRAINT ALL;
ALTER TABLE ELEProductos NOCHECK CONSTRAINT ALL;
ALTER TABLE ELETiendaProducto NOCHECK CONSTRAINT ALL;
ALTER TABLE ELETiendas NOCHECK CONSTRAINT ALL;
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  Table [dbo].[ELECategorias]    Script Date: 03/11/2024 01:04:07 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  Table [dbo].[ELEClientes]    Script Date: 03/11/2024 01:04:07 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  Table [dbo].[ELEEmpleados]    Script Date: 03/11/2024 01:04:07 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  Table [dbo].[ELEFacturaEnc]    Script Date: 03/11/2024 01:04:07 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  Table [dbo].[ELEFacturasDet]    Script Date: 03/11/2024 01:04:07 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  Table [dbo].[ELEMarcas]    Script Date: 03/11/2024 01:04:07 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  Table [dbo].[ELEProductos]    Script Date: 03/11/2024 01:04:07 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  Table [dbo].[ELETiendaProducto]    Script Date: 03/11/2024 01:04:07 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  Table [dbo].[ELETiendas]    Script Date: 03/11/2024 01:04:07 a. m. ******/
SET ANSI_NULLS ON
GO
DELETE FROM ELECargos;
DELETE FROM ELECategorias;
DELETE FROM ELEClientes;
DELETE FROM ELEEmpleados;
DELETE FROM ELEFacturaEnc;
DELETE FROM ELEFacturasDet;
DELETE FROM ELEMarcas;
DELETE FROM ELEProductos;
DELETE FROM ELETiendaProducto;
DELETE FROM ELETiendas;
SET QUOTED_IDENTIFIER ON
GO
INSERT [dbo].[ELECargos] ([CodCargo], [Descripcion]) VALUES (1, N'Gerente de tienda')
GO
INSERT [dbo].[ELECargos] ([CodCargo], [Descripcion]) VALUES (2, N'Cajero')
GO
INSERT [dbo].[ELECargos] ([CodCargo], [Descripcion]) VALUES (3, N'Goldolero')
GO
INSERT [dbo].[ELECargos] ([CodCargo], [Descripcion]) VALUES (4, N'Chofer')
GO
INSERT [dbo].[ELECargos] ([CodCargo], [Descripcion]) VALUES (5, N'Bodeguero')
GO
INSERT [dbo].[ELECargos] ([CodCargo], [Descripcion]) VALUES (6, N'Vendedor')
GO
INSERT [dbo].[ELECargos] ([CodCargo], [Descripcion]) VALUES (7, N'Oficial de seguridad')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (1, N'Freidora de aire')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (2, N'Cocina')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (3, N'Lavadora de platos')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (4, N'Lavadora de ropa')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (5, N'Horno de Micro ondas')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (6, N'Refrigeradora')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (7, N'Batidora')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (8, N'Procesador de alimentos')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (9, N'Cogelador')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (10, N'Robot aspiradora')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (11, N'Pantallas')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (12, N'Tostadora')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (13, N'Secadora de ropa')
GO
INSERT [dbo].[ELECategorias] ([CodCategoria], [Descripcion]) VALUES (14, N'Centro de lavado')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (1, N'103220165', N'MARIA CLEMENCIA', N'JIMENEZ', N'JIMENEZ', N'Cartago Centro                                             ', N'mariaclemencia.jimenez.jimenez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (2, N'103220166', N'FLOR MARIA', N'FERNANDEZ', N'FERNANDEZ', N'ZAPOTE                                                  ', N'flormaria.fernandez.fernandez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (3, N'103220169', N'CECILIA', N'SANCHEZ', N'SANCHEZ', N'SAN FRANCISCO DE DOS RIOS                               ', N'cecilia.sanchez.sanchez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (4, N'103220171', N'VICTOR', N'MEZA', N'MEZA', N'URUCA                                                   ', N'victor.meza.meza@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (5, N'103220173', N'MIRIAN', N'CORRALES', N'CORRALES', N'MATA REDONDA                                            ', N'mirian.corrales.corrales@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (6, N'103220175', N'FLOR MARIA', N'FERNANDEZ', N'FERNANDEZ', N'PAVAS                                                   ', N'flormaria.fernandez.fernandez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (7, N'103220178', N'FLOR MARIA', N'UMAÑA', N'UMAÑA', N'HATILLO                                                 ', N'flormaria.umaña.umaña@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (8, N'103220179', N'MARCO NEY', N'CECILIANO', N'CECILIANO', N'SAN SEBASTIAN                                           ', N'marconey.ceciliano.ceciliano@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (9, N'103220181', N'CRISTINA', N'LOPEZ', N'LOPEZ', N'LA CAJA                                                 ', N'cristina.lopez.lopez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (10, N'103220189', N'OSCAR FRANCISCO', N'CHACON', N'CHACON', N'PASO ANCHO SUR                                          ', N'oscarfrancisco.chacon.chacon@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (11, N'103220192', N'AMABLE', N'SANCHEZ', N'SANCHEZ', N'CARMEN                                                  ', N'amable.sanchez.sanchez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (12, N'103220193', N'MARIA DE LOS ANGELES', N'FLORES', N'FLORES', N'BARRIO MEXICO                                           ', N'mariadelosangeles.flores.flores@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (13, N'103220195', N'LIDIA', N'ESPINOZA', N'ESPINOZA', N'CATEDRAL                                                ', N'lidia.espinoza.espinoza@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (14, N'103220196', N'JUANA', N'ESPINOZA', N'ESPINOZA', N'CORAZON DE JESUS                                        ', N'juana.espinoza.espinoza@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (15, N'103220197', N'JORGE ANTONIO', N'VARGAS', N'VARGAS', N'ARANJUEZ                                                ', N'jorgeantonio.vargas.vargas@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (16, N'103220200', N'JOSE ANTONIO', N'VARGAS', N'VARGAS', N'PITAHAYA                                                ', N'joseantonio.vargas.vargas@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (17, N'103220203', N'ARNOLDO', N'UMAÑA', N'UMAÑA', N'CRISTO REY                                              ', N'arnoldo.umaña.umaña@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (18, N'103220205', N'LIDIA MARIA', N'ZAMORA', N'ZAMORA', N'OMAR DENGO                                              ', N'lidiamaria.zamora.zamora@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (19, N'103220207', N'RIGOBERTO', N'LEON', N'LEON', N'SAN BOSCO                                               ', N'rigoberto.leon.leon@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (20, N'103220210', N'CARMEN TERESITA', N'ROMERO', N'ROMERO', N'GONZALEZ VIQUEZ                                         ', N'carmenteresita.romero.romero@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (21, N'103220212', N'VIRGINIA', N'RAWSON', N'RAWSON', N'NACIONES UNIDAS                                         ', N'virginia.rawson.rawson@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (22, N'103220215', N'LEONEL', N'ALVARADO', N'ALVARADO', N'BARRIO LUJAN                                            ', N'leonel.alvarado.alvarado@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (23, N'103220216', N'MARIA CECILIA', N'LE ROY', N'LE ROY', N'PASO ANCHO NORTE                                        ', N'mariacecilia.leroy.leroy@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (24, N'103220217', N'GLADYS', N'MURILLO', N'MURILLO', N'SAGRADA FAMILIA                                         ', N'gladys.murillo.murillo@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (25, N'103220219', N'LIGIA', N'VARGAS', N'VARGAS', N'RINCON GRANDE                                           ', N'ligia.vargas.vargas@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (26, N'103220223', N'MARIA DE LOS ANGELES', N'CORDERO', N'CORDERO', N'MARIA REINA                                             ', N'mariadelosangeles.cordero.cordero@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (27, N'103220224', N'MARIA DEL CARMEN', N'AZOFEIFA', N'AZOFEIFA', N'VILLA ESPERANZA                                         ', N'mariadelcarmen.azofeifa.azofeifa@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (28, N'103220225', N'MARIA CRISTINA', N'LOPEZ', N'LOPEZ', N'ROSITER CARBALLO (LAS BRISAS)                           ', N'mariacristina.lopez.lopez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (29, N'103220228', N'VICTOR EMILIO', N'CHACON', N'CHACON', N'CAI. SAN JOSE                                           ', N'victoremilio.chacon.chacon@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (30, N'103220229', N'JUANA PILAR', N'PEREZ', N'PEREZ', N'LA CARPIO                                               ', N'juanapilar.perez.perez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (31, N'103220230', N'ERMELINDA', N'HERNANDEZ', N'HERNANDEZ', N'CORDOBA                                                 ', N'ermelinda.hernandez.hernandez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (32, N'103220232', N'JOSE RAMON', N'LEON', N'LEON', N'SANTA MARTA                                             ', N'joseramon.leon.leon@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (33, N'103220233', N'MARIA VIRGINIA', N'AGUIRRE', N'AGUIRRE', N'LA PEREGRINA                                            ', N'mariavirginia.aguirre.aguirre@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (34, N'103220236', N'ELSA', N'MARIN', N'MARIN', N'PERPETUO SOCORRO                                        ', N'elsa.marin.marin@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (35, N'103220239', N'ANAIS', N'FONSECA', N'FONSECA', N'HATILLO 8                                               ', N'anais.fonseca.fonseca@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (36, N'103220240', N'FLOR DE MARIA', N'ILAMA', N'ILAMA', N'COLONIA 15 DE SETIEMBRE                                 ', N'flordemaria.ilama.ilama@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (37, N'103220241', N'ADILIA', N'GODINEZ', N'GODINEZ', N'COLONIA KENNEDY                                         ', N'adilia.godinez.godinez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (38, N'103220243', N'RAMON', N'CORDOBA', N'CORDOBA', N'C.S.M CAPEMCOL                                          ', N'ramon.cordoba.cordoba@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (39, N'103220244', N'HILDA MARIA', N'ABARCA', N'ABARCA', N'ESCAZU                                                   ', N'hildamaria.abarca.abarca@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (40, N'103220246', N'VICTOR MANUEL', N'RAMIREZ', N'RAMIREZ', N'SAN ANTONIO                                              ', N'victormanuel.ramirez.ramirez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (41, N'103220248', N'EIDA JUANA', N'BARQUERO', N'BARQUERO', N'SAN RAFAEL                                               ', N'eidajuana.barquero.barquero@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (42, N'103220252', N'GUILLERMO', N'TREJOS', N'TREJOS', N'BEBEDERO O SAN FRANCISCO                                 ', N'guillermo.trejos.trejos@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (43, N'103220253', N'NIDIA', N'FALLAS', N'FALLAS', N'GUACHIPELIN (SAN GABRIEL)                                ', N'nidia.fallas.fallas@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (44, N'103220258', N'PABLO', N'MORA', N'MORA', N'CARMEN (CHIVERRAL)                                       ', N'pablo.mora.mora@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (45, N'103220262', N'NORMA', N'FERNANDEZ', N'FERNANDEZ', N'BELO HORIZONTE NORTE                                     ', N'norma.fernandez.fernandez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (46, N'103220265', N'CECILIA', N'TORRES', N'TORRES', N'HLE. MAGDALA                                             ', N'cecilia.torres.torres@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (47, N'103220267', N'BELISA MELIDA', N'CUBILLO', N'CUBILLO', N'DESAMPARADOS                                       ', N'belisamelida.cubillo.cubillo@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (48, N'103220268', N'RAFAEL', N'MORA', N'MORA', N'SAN MIGUEL                                         ', N'rafael.mora.mora@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (49, N'103220272', N'JOSE MARIA', N'SALAZAR', N'SALAZAR', N'JERICO                                             ', N'josemaria.salazar.salazar@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (50, N'103220274', N'VIRGINIA', N'SANABRIA', N'SANABRIA', N'HIGUITO                                            ', N'virginia.sanabria.sanabria@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (51, N'103220277', N'VIOLETA', N'BRENES', N'BRENES', N'SAN JUAN DE DIOS                                   ', N'violeta.brenes.brenes@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (52, N'103220279', N'MARIA DE LOS ANGELES', N'OBANDO', N'OBANDO', N'SAN RAFAEL ARRIBA                                  ', N'mariadelosangeles.obando.obando@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (53, N'103220281', N'GUILLERMO', N'BLANCO', N'BLANCO', N'SAN RAFAEL ABAJO                                   ', N'guillermo.blanco.blanco@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (54, N'103220283', N'GERARDO', N'MARIN', N'MARIN', N'SAN ANTONIO                                        ', N'gerardo.marin.marin@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (55, N'103220284', N'ORLANDO', N'MULLER', N'MULLER', N'FRAILES                                            ', N'orlando.muller.muller@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (56, N'103220289', N'ANA CECILIA', N'SOJO', N'SOJO', N'BUSTAMANTE O ALCIRA                                ', N'anacecilia.sojo.sojo@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (57, N'103220291', N'CARMEN ROSA', N'VARGAS', N'VARGAS', N'PATARRA                                            ', N'carmenrosa.vargas.vargas@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (58, N'103220292', N'CECILIA DE LOS ANGELES', N'SOLIS', N'SOLIS', N'SAN CRISTOBAL SUR                                  ', N'ceciliadelosangeles.solis.solis@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (59, N'103220293', N'ALBERTO', N'QUINTANA', N'QUINTANA', N'SAN CRISTOBAL NORTE                                ', N'alberto.quintana.quintana@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (60, N'103220294', N'MARTA ODILIE', N'JIMENEZ', N'JIMENEZ', N'ROSARIO                                            ', N'martaodilie.jimenez.jimenez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (61, N'103220296', N'SOLEDAD MIRIAM', N'HERNANDEZ', N'HERNANDEZ', N'GUADARRAMA                                         ', N'soledadmiriam.hernandez.hernandez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (62, N'104150205', N'EDITH', N'MARTINEZ', N'MARTINEZ', N'LA JOYA                                            ', N'edith.martinez.martinez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (63, N'104150206', N'MARITZA', N'ELIZONDO', N'ELIZONDO', N'FATIMA DE DAMAS                                    ', N'maritza.elizondo.elizondo@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (64, N'104150207', N'JOSE ROBERTO', N'VENEGAS', N'VENEGAS', N'CALLE FALLAS                                       ', N'joseroberto.venegas.venegas@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (65, N'104150209', N'CARLOS ANTONIO', N'SOLORZANO', N'SOLORZANO', N'GRAVILIAS                                          ', N'carlosantonio.solorzano.solorzano@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (66, N'104150210', N'RONALD GERARDO', N'FERNANDEZ', N'FERNANDEZ', N'PACAYA                                             ', N'ronaldgerardo.fernandez.fernandez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (67, N'104150211', N'MARCO TULIO', N'SALAZAR', N'SALAZAR', N'EL LLANO                                           ', N'marcotulio.salazar.salazar@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (68, N'104150212', N'GLADYS MARIA', N'PANIAGUA', N'PANIAGUA', N'MANZANO (MANZANILLO)                               ', N'gladysmaria.paniagua.paniagua@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (69, N'104150214', N'FLOR DE MARIA', N'GARRO', N'GARRO', N'GUATUSO                                            ', N'flordemaria.garro.garro@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (70, N'104150215', N'JOSE GABRIEL', N'MORA', N'MORA', N'TRINIDAD (PARTE ESTE)                              ', N'josegabriel.mora.mora@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (71, N'104150216', N'MAYELA', N'PORRAS', N'PORRAS', N'CRISTO REY                                         ', N'mayela.porras.porras@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (72, N'104150217', N'JUAN', N'HERNANDEZ', N'HERNANDEZ', N'LOS GUIDO                                          ', N'juan.hernandez.hernandez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (73, N'104150219', N'ROBERTO', N'BOLAÑOS', N'BOLAÑOS', N'LAS LOMAS                                          ', N'roberto.bolaños.bolaños@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (74, N'104150220', N'NITZA MARGARITA', N'CEDEÑO', N'CEDEÑO', N'SAN JERONIMO                                       ', N'nitzamargarita.cedeño.cedeño@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (75, N'104150221', N'WILLIAM', N'MENDEZ', N'MENDEZ', N'VIOLETA (RINCON MORALES)                           ', N'william.mendez.mendez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (76, N'104150224', N'FERNANDO', N'OBANDO', N'OBANDO', N'SAN LORENZO                                        ', N'fernando.obando.obando@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (77, N'104150225', N'RODOLFO', N'CEDEÑO', N'CEDEÑO', N'VALENCIA                                           ', N'rodolfo.cedeño.cedeño@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (78, N'104150226', N'RODOLFO ANTONIO', N'GONZALEZ', N'GONZALEZ', N'EL PORVENIR                                        ', N'rodolfoantonio.gonzalez.gonzalez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (79, N'104150229', N'GERARDO', N'SOLANO', N'SOLANO', N'LA CAPRI                                           ', N'gerardo.solano.solano@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (80, N'104150230', N'MARCO ANTONIO', N'LEIVA', N'LEIVA', N'CAI. VILMA CURLING RIVERA                          ', N'marcoantonio.leiva.leiva@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (81, N'104150232', N'OLGA ISABEL', N'HERNANDEZ', N'HERNANDEZ', N'EMPALME ARRIBA GUARIA(PARTE OESTE)                 ', N'olgaisabel.hernandez.hernandez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (82, N'104150234', N'SONIA', N'ZUÑIGA', N'ZUÑIGA', N'HLE. OFELIA CARVAJAL DE NARANJO                    ', N'sonia.zuñiga.zuñiga@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (83, N'104150235', N'LUCIA', N'ESTRADA', N'ESTRADA', N'HLE. SAN CAYETANO                                  ', N'lucia.estrada.estrada@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (84, N'104150236', N'LUIS RODOLFO', N'UVA', N'UVA', N'LLANO BONITO                                       ', N'luisrodolfo.uva.uva@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (85, N'104150237', N'ALEJANDRO', N'BARAHONA', N'BARAHONA', N'CHIROGRES                                          ', N'alejandro.barahona.barahona@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (86, N'104150238', N'ALVARO GERARDO', N'MORA', N'MORA', N'SANTIAGO                                               ', N'alvarogerardo.mora.mora@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (87, N'104150240', N'SONIA', N'ARAGON', N'ARAGON', N'POZOS                                                  ', N'sonia.aragon.aragon@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (88, N'104150241', N'MAYELA', N'MELENDEZ', N'MELENDEZ', N'MERCEDES SUR                                           ', N'mayela.melendez.melendez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (89, N'104150242', N'CARMEN MAYELA', N'MUÑOZ', N'MUÑOZ', N'MERCEDES NORTE                                         ', N'carmenmayela.muñoz.muñoz@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (90, N'104150244', N'MARIA DE LOS ANGELES', N'MARIN', N'MARIN', N'BOCANA                                                 ', N'mariadelosangeles.marin.marin@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (91, N'104150245', N'LIGIA MARIA', N'VALERIN', N'VALERIN', N'JILGUERAL                                              ', N'ligiamaria.valerin.valerin@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (92, N'104150248', N'BLANCA MARIA', N'SOLANO', N'SOLANO', N'TUFARES                                                ', N'blancamaria.solano.solano@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (93, N'104150249', N'JUANA MARIA', N'MORA', N'MORA', N'SALITRALES                                             ', N'juanamaria.mora.mora@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (94, N'104150251', N'ANA ISABEL', N'MADRIZ', N'MADRIZ', N'ALTO LA PALMA                                          ', N'anaisabel.madriz.madriz@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (95, N'104150252', N'MARIA DE LOS ANGELES', N'ZUÑIGA', N'ZUÑIGA', N'LOS GUIDO                                          ', N'mariadelosangeles.zuñiga.zuñiga@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (96, N'104150253', N'LILIANA', N'RODRIGUEZ', N'RODRIGUEZ', N'LAS LOMAS                                          ', N'liliana.rodriguez.rodriguez@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (97, N'104150254', N'LILLIAM MAYELA', N'ROJAS', N'ROJAS', N'SAN JERONIMO                                       ', N'lilliammayela.rojas.rojas@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (98, N'104150260', N'ANA LORENA', N'VEGA', N'VEGA', N'VIOLETA (RINCON MORALES)                           ', N'analorena.vega.vega@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (99, N'104150261', N'MARTA EUGENIA', N'ARCE', N'ARCE', N'SAN LORENZO                                        ', N'martaeugenia.arce.arce@gmail.com')
GO
INSERT [dbo].[ELEClientes] ([CodCliente], [Identificacion], [Nombre], [Apellido1], [Apellido2], [Direccion], [Email]) VALUES (100, N'104150262', N'VICTOR MANUEL', N'MORA', N'MORA', N'VALENCIA                                           ', N'victormanuel.mora.mora@gmail.com')
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (1, N'604150537', N'GRECIANA VIRGINIA', N'PORRAS', N'PORRAS', NULL, 1, 1)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (2, N'604680869', N'IRAN BEATRIZ', N'GARCIA', N'GARCIA', NULL, 1, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (3, N'504130491', N'KARINA', N'VASQUEZ', N'VASQUEZ', NULL, 1, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (4, N'302890926', N'WALTER', N'SERRANO', N'SERRANO', NULL, 1, 4)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (5, N'504130489', N'JOSE MARIA', N'URBINA', N'URBINA', NULL, 1, 5)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (6, N'504090623', N'JUAN ANTONIO', N'CAMACHO', N'CAMACHO', NULL, 1, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (7, N'504090612', N'JOSE ANDRES', N'ALEMAN', N'ALEMAN', NULL, 1, 7)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (8, N'118770803', N'VALERIA ISABEL', N'CEDEÑO', N'CEDEÑO', NULL, 1, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (9, N'118280607', N'KAREN', N'CORDERO', N'CORDERO', NULL, 1, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (10, N'118770811', N'ASHLYN NICOLE', N'GONZALEZ', N'GONZALEZ', NULL, 1, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (11, N'118770761', N'PAOLA DE LOS ANGELES', N'MONTOYA', N'MONTOYA', NULL, 2, 1)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (12, N'118770804', N'BRANDON JOSUE', N'VARGAS', N'VARGAS', CAST(N'2013-05-07T00:00:00.0000000' AS DateTime2), 2, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (13, N'604150528', N'CRISTEL SUSET', N'ESPINOZA', N'ESPINOZA', CAST(N'2015-11-07T00:00:00.0000000' AS DateTime2), 2, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (14, N'118770799', N'BRANDY JIMENA', N'SEPULVEDA', N'SEPULVEDA', NULL, 2, 4)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (15, N'118770754', N'LEONARDO ANDRES', N'CECILIANO', N'CECILIANO', NULL, 2, 5)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (16, N'205430837', N'FABIAN FRANCISCO', N'CAMPOS', N'CAMPOS', CAST(N'2017-05-04T00:00:00.0000000' AS DateTime2), 2, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (17, N'604150526', N'BRAYAN ANULFO', N'CHACON', N'CHACON', NULL, 2, 7)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (18, N'604150561', N'LUCERO', N'ROJAS', N'ROJAS', CAST(N'2013-09-04T00:00:00.0000000' AS DateTime2), 2, 5)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (19, N'302410339', N'SONIA MARIA', N'BRENES', N'BRENES', NULL, 2, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (20, N'504090643', N'MARIA ANGELICA', N'VARELA', N'VARELA', CAST(N'2016-06-03T00:00:00.0000000' AS DateTime2), 2, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (21, N'118280588', N'MICHAEL STEVEN', N'OCHOA', N'OCHOA', CAST(N'2021-03-11T00:00:00.0000000' AS DateTime2), 3, 1)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (22, N'504090647', N'MERCEDES DEL SOCORRO', N'RAMOS', N'RAMOS', NULL, 3, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (23, N'302600441', N'BERNARDITA', N'MATA', N'MATA', NULL, 3, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (24, N'504130510', N'ADRIANA DE LOS ANGELES', N'LOPEZ', N'LOPEZ', NULL, 3, 4)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (25, N'501401108', N'ANA CRISTINA', N'BELMONTE', N'BELMONTE', CAST(N'2022-05-03T00:00:00.0000000' AS DateTime2), 3, 5)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (26, N'302410325', N'ISABEL', N'BRAVO', N'BRAVO', CAST(N'2018-05-03T00:00:00.0000000' AS DateTime2), 3, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (27, N'118770758', N'JOSE DAVID', N'PADILLA', N'PADILLA', NULL, 3, 7)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (28, N'504130536', N'FRANK', N'QUIROS', N'QUIROS', CAST(N'2013-03-05T00:00:00.0000000' AS DateTime2), 3, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (29, N'501401105', N'JUAN RAFAEL', N'CHAVES', N'CHAVES', CAST(N'2022-02-03T00:00:00.0000000' AS DateTime2), 3, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (30, N'302890988', N'LUIS FERNANDO', N'MONGE', N'MONGE', NULL, 3, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (31, N'302600449', N'JULIO FERNANDO', N'SERRANO', N'SERRANO', NULL, 4, 1)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (32, N'604150545', N'LAURA DEL SOCORRO', N'NAJERA', N'NAJERA', NULL, 4, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (33, N'302410372', N'EDWIN FRANCISCO', N'CORDERO', N'CORDERO', CAST(N'2012-07-10T00:00:00.0000000' AS DateTime2), 4, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (34, N'205430864', N'ANGELICA MARIA', N'MADRIGAL', N'MADRIGAL', CAST(N'2019-07-12T00:00:00.0000000' AS DateTime2), 4, 4)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (35, N'302600389', N'JOSE JOAQUIN', N'CHACON', N'CHACON', NULL, 4, 5)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (36, N'604150539', N'ANDREA MARIA', N'BERMUDEZ', N'BERMUDEZ', NULL, 4, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (37, N'302410335', N'LUIS EUGENIO', N'CALVO', N'CALVO', CAST(N'2018-10-09T00:00:00.0000000' AS DateTime2), 4, 7)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (38, N'504090657', N'ERICK DAVID', N'TORRES', N'TORRES', NULL, 4, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (39, N'302890933', N'VIVIAN', N'PEÑARANDA', N'PEÑARANDA', NULL, 4, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (40, N'205430866', N'MARIA JENIFEER', N'SEGURA', N'SEGURA', NULL, 4, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (41, N'302410332', N'MARIO ALBERTO', N'CUBERO', N'CUBERO', CAST(N'2023-02-08T00:00:00.0000000' AS DateTime2), 5, 1)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (42, N'302600427', N'JOSE FRANCISCO', N'HERNANDEZ', N'HERNANDEZ', CAST(N'2020-11-02T00:00:00.0000000' AS DateTime2), 5, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (43, N'502650498', N'ABRAHAM', N'HERNANDEZ', N'HERNANDEZ', NULL, 5, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (44, N'504130495', N'MARLON WILBERTH', N'ROMERO', N'ROMERO', NULL, 5, 4)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (45, N'205430806', N'ALONSO ENRIQUE', N'CAMPOS', N'CAMPOS', NULL, 5, 5)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (46, N'502650488', N'FREDDY ANGEL', N'AGUIRRE', N'AGUIRRE', CAST(N'2024-06-02T00:00:00.0000000' AS DateTime2), 5, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (47, N'501401107', N'JESUS', N'RUIZ', N'RUIZ', CAST(N'2021-01-07T00:00:00.0000000' AS DateTime2), 5, 7)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (48, N'504090648', N'GERARDO JOSE', N'RIVERA', N'RIVERA', NULL, 5, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (49, N'302410375', N'ALFREDO', N'BARQUERO', N'BARQUERO', NULL, 5, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (50, N'118770791', N'JOSHUA DANIEL', N'LOPEZ', N'LOPEZ', CAST(N'2021-08-03T00:00:00.0000000' AS DateTime2), 5, 7)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (51, N'205430850', N'LISBETH', N'GRANADOS', N'GRANADOS', NULL, 6, 1)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (52, N'302600437', N'LIGIA MARIA', N'GUTIERREZ', N'GUTIERREZ', NULL, 6, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (53, N'504090663', N'ADRIANA DE LOS ANGELES', N'NUÑEZ', N'NUÑEZ', NULL, 6, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (54, N'604150585', N'ODEDH', N'REINOR', N'REINOR', CAST(N'2015-04-04T00:00:00.0000000' AS DateTime2), 6, 4)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (55, N'118280579', N'STACY NICOLE', N'GUTIERREZ', N'GUTIERREZ', CAST(N'2013-02-04T00:00:00.0000000' AS DateTime2), 6, 5)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (56, N'118770776', N'GUSTAVO JOSE', N'CORDERO', N'CORDERO', CAST(N'2020-07-01T00:00:00.0000000' AS DateTime2), 6, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (57, N'205430854', N'MAURICIO JOSE', N'CAMPOS', N'CAMPOS', CAST(N'2014-07-01T00:00:00.0000000' AS DateTime2), 6, 7)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (58, N'604150575', N'DANIELA MARIA', N'GUZMAN', N'GUZMAN', NULL, 6, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (59, N'604150564', N'KIMBERLY SHIRLEY', N'RIVAS', N'RIVAS', CAST(N'2012-10-06T00:00:00.0000000' AS DateTime2), 6, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (60, N'504130527', N'YUDINETH DAYAN', N'LOPEZ', N'LOPEZ', NULL, 6, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (61, N'504130485', N'ALEJANDRA MARIA', N'MARTINEZ', N'MARTINEZ', NULL, 6, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (62, N'504130492', N'JOSE MANUEL', N'RUIZ', N'RUIZ', NULL, 7, 1)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (63, N'604150570', N'JOSSELINE REBECA', N'VICTOR', N'VICTOR', CAST(N'2022-07-12T00:00:00.0000000' AS DateTime2), 7, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (64, N'118280583', N'ADRIAN JOSE', N'CARMONA', N'CARMONA', CAST(N'2017-01-02T00:00:00.0000000' AS DateTime2), 7, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (65, N'504090642', N'JOSE JEHUDY', N'POMARES', N'POMARES', NULL, 7, 4)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (66, N'118770784', N'MARIA VALERIA', N'ESQUIVEL', N'ESQUIVEL', CAST(N'2018-06-11T00:00:00.0000000' AS DateTime2), 7, 5)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (67, N'118770818', N'JONATHAN MOISES', N'MOLINA', N'MOLINA', CAST(N'2022-02-12T00:00:00.0000000' AS DateTime2), 7, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (68, N'604150538', N'KESIEL SADRAC', N'VILLALOBOS', N'VILLALOBOS', NULL, 7, 7)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (69, N'504090608', N'RANDALL ALBERTO', N'JUNEZ', N'JUNEZ', NULL, 7, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (70, N'302890939', N'PRISCILLA', N'JIMENEZ', N'JIMENEZ', CAST(N'2021-11-04T00:00:00.0000000' AS DateTime2), 7, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (71, N'118280568', N'ANDER', N'CASCANTE', N'CASCANTE', NULL, 8, 1)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (72, N'302410342', N'ALBERTO', N'AGUILAR', N'AGUILAR', CAST(N'2019-04-03T00:00:00.0000000' AS DateTime2), 8, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (73, N'302600410', N'JOSE ANTONIO', N'MORA', N'MORA', CAST(N'2018-02-09T00:00:00.0000000' AS DateTime2), 8, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (74, N'302890986', N'VERA LILIANA', N'ROLDAN', N'ROLDAN', NULL, 8, 4)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (75, N'504090606', N'ARGERIE MARIA', N'RODRIGUEZ', N'RODRIGUEZ', NULL, 8, 5)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (76, N'504090667', N'IZA MARA', N'FERNANDEZ', N'FERNANDEZ', NULL, 8, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (77, N'504130514', N'EVER', N'ESPINOZA', N'ESPINOZA', NULL, 8, 7)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (78, N'302410323', N'ROSA', N'QUIROS', N'QUIROS', CAST(N'2019-09-04T00:00:00.0000000' AS DateTime2), 8, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (79, N'302890924', N'ASDRUBAL', N'MENDEZ', N'MENDEZ', CAST(N'2012-06-08T00:00:00.0000000' AS DateTime2), 8, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (80, N'604680874', N'VALERIA PRISCILLA', N'BUSTOS', N'BUSTOS', NULL, 8, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (81, N'118280562', N'VALERY ABIGAIL', N'SEVILLA', N'SEVILLA', NULL, 9, 1)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (82, N'302600411', N'DIGNA', N'SOJO', N'SOJO', NULL, 9, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (83, N'504090639', N'MELISSA MARGARITA', N'ULLOA', N'ULLOA', NULL, 9, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (84, N'302890971', N'SERGIO HUMBERTO', N'QUIROS', N'QUIROS', CAST(N'2024-08-03T00:00:00.0000000' AS DateTime2), 9, 4)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (85, N'604680859', N'STUART FRANCISCO', N'ANGULO', N'ANGULO', CAST(N'2023-12-08T00:00:00.0000000' AS DateTime2), 9, 5)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (86, N'118770792', N'MARIPAZ', N'GUTIERREZ', N'GUTIERREZ', CAST(N'2011-02-04T00:00:00.0000000' AS DateTime2), 9, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (87, N'302600417', N'JOSE ANGEL', N'AVENDAÑO', N'AVENDAÑO', NULL, 9, 7)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (88, N'302890967', N'WALTER', N'MUÑOZ', N'MUÑOZ', CAST(N'2023-01-01T00:00:00.0000000' AS DateTime2), 9, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (89, N'501401129', N'JOSE LUIS', N'RIVERA', N'RIVERA', NULL, 9, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (90, N'302890920', N'ANA MARIA', N'RIVERA', N'RIVERA', NULL, 9, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (91, N'118280547', N'CHRISTOPHER ANTONIO', N'ROSALES', N'ROSALES', NULL, 10, 1)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (92, N'118770800', N'TANIA MARIA', N'MARIN', N'MARIN', NULL, 10, 2)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (93, N'504130488', N'WILMER ANTONIO', N'AREVALO', N'AREVALO', NULL, 10, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (94, N'302410317', N'MARIA ISABEL', N'GRANADOS', N'GRANADOS', NULL, 10, 4)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (95, N'604150546', N'NELSON JOSE', N'JIMENEZ', N'JIMENEZ', NULL, 10, 5)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (96, N'604680871', N'SAYMOND JOSUE', N'RODRIGUEZ', N'RODRIGUEZ', CAST(N'2024-03-06T00:00:00.0000000' AS DateTime2), 10, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (97, N'205430833', N'OSVALDO', N'MASIS', N'MASIS', CAST(N'2015-04-06T00:00:00.0000000' AS DateTime2), 10, 7)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (98, N'501401068', N'JOSE JOAQUIN', N'CASTILLO', N'CASTILLO', NULL, 10, 3)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (99, N'302890930', N'ANA GABRIELA', N'VEGA', N'VEGA', CAST(N'2015-09-07T00:00:00.0000000' AS DateTime2), 10, 6)
GO
INSERT [dbo].[ELEEmpleados] ([CodEmpleado], [Identificacion], [Nombre], [Apellido1], [Apellido2], [FecIngreso], [CodTienda], [CodCargo]) VALUES (100, N'118770815', N'JEFFERSON', N'QUESADA', N'QUESADA', NULL, 10, 6)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (1, NULL, 34, 95, 5, CAST(1207425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (2, NULL, 34, 36, 4, CAST(1219945 AS Decimal(10, 0)), CAST(N'2018-01-02T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (3, CAST(N'2018-06-02T00:00:00.0000000' AS DateTime2), 97, 22, 6, CAST(1183346 AS Decimal(10, 0)), CAST(N'2018-07-02T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (4, NULL, 25, 16, 3, CAST(1499700 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (5, NULL, 4, 2, 1, CAST(385270 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (6, CAST(N'2018-03-03T00:00:00.0000000' AS DateTime2), 75, 97, 5, CAST(240005 AS Decimal(10, 0)), CAST(N'2018-04-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (7, CAST(N'2018-06-03T00:00:00.0000000' AS DateTime2), 12, 78, 2, CAST(685270 AS Decimal(10, 0)), CAST(N'2018-07-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (8, CAST(N'2018-08-03T00:00:00.0000000' AS DateTime2), 42, 30, 8, CAST(44900 AS Decimal(10, 0)), CAST(N'2018-09-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (9, NULL, 97, 75, 9, CAST(701562 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (10, CAST(N'2018-02-04T00:00:00.0000000' AS DateTime2), 4, 37, 10, CAST(240005 AS Decimal(10, 0)), CAST(N'2018-03-04T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (11, NULL, 30, 21, 8, CAST(17425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (12, NULL, 32, 61, 6, CAST(22425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (13, CAST(N'2018-06-05T00:00:00.0000000' AS DateTime2), 7, 14, 1, CAST(131190 AS Decimal(10, 0)), CAST(N'2018-07-05T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (14, CAST(N'2018-07-05T00:00:00.0000000' AS DateTime2), 96, 2, 8, CAST(34425 AS Decimal(10, 0)), CAST(N'2018-08-05T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (15, NULL, 14, 92, 3, CAST(499890 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (16, NULL, 85, 92, 10, CAST(54990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (17, CAST(N'2018-04-06T00:00:00.0000000' AS DateTime2), 39, 23, 3, CAST(164970 AS Decimal(10, 0)), CAST(N'2018-05-06T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (18, NULL, 64, 73, 8, CAST(101175 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (19, NULL, 100, 27, 3, CAST(149925 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (20, NULL, 59, 90, 10, CAST(385270 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (21, CAST(N'2018-10-07T00:00:00.0000000' AS DateTime2), 23, 83, 5, CAST(44900 AS Decimal(10, 0)), CAST(N'2018-11-07T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (22, NULL, 34, 47, 1, CAST(285000 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (23, CAST(N'2018-02-08T00:00:00.0000000' AS DateTime2), 6, 62, 2, CAST(209900 AS Decimal(10, 0)), CAST(N'2018-03-08T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (24, NULL, 83, 47, 9, CAST(101175 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (25, NULL, 13, 27, 1, CAST(109900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (26, NULL, 78, 32, 6, CAST(899900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (27, CAST(N'2018-02-09T00:00:00.0000000' AS DateTime2), 67, 58, 8, CAST(22425 AS Decimal(10, 0)), CAST(N'2018-03-09T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (28, NULL, 3, 44, 6, CAST(191385 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (29, NULL, 55, 38, 8, CAST(371375 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (30, CAST(N'2018-05-10T00:00:00.0000000' AS DateTime2), 60, 49, 9, CAST(139900 AS Decimal(10, 0)), CAST(N'2018-06-10T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (31, NULL, 29, 38, 6, CAST(399330 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (32, NULL, 74, 39, 1, CAST(2999970 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (33, CAST(N'2018-01-11T00:00:00.0000000' AS DateTime2), 88, 37, 10, CAST(350781 AS Decimal(10, 0)), CAST(N'2018-02-11T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (34, NULL, 82, 53, 3, CAST(10000 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (35, NULL, 10, 24, 8, CAST(451905 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (36, NULL, 72, 34, 8, CAST(742750 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (37, CAST(N'2018-06-12T00:00:00.0000000' AS DateTime2), 6, 84, 3, CAST(17425 AS Decimal(10, 0)), CAST(N'2018-07-12T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (38, NULL, 66, 79, 2, CAST(40125 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (39, NULL, 17, 44, 9, CAST(249900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (40, CAST(N'2019-01-01T00:00:00.0000000' AS DateTime2), 68, 91, 6, CAST(149980 AS Decimal(10, 0)), CAST(N'2019-02-01T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (41, CAST(N'2019-09-01T00:00:00.0000000' AS DateTime2), 22, 89, 1, CAST(285000 AS Decimal(10, 0)), CAST(N'2019-10-01T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (42, NULL, 46, 83, 8, CAST(449990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (43, NULL, 13, 48, 3, CAST(899900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (44, CAST(N'2019-02-02T00:00:00.0000000' AS DateTime2), 35, 60, 5, CAST(423600 AS Decimal(10, 0)), CAST(N'2019-03-02T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (45, CAST(N'2019-08-02T00:00:00.0000000' AS DateTime2), 8, 11, 8, CAST(40125 AS Decimal(10, 0)), CAST(N'2019-09-02T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (46, NULL, 45, 64, 2, CAST(482900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (47, CAST(N'2019-04-03T00:00:00.0000000' AS DateTime2), 33, 98, 4, CAST(385270 AS Decimal(10, 0)), CAST(N'2019-05-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (48, NULL, 90, 24, 10, CAST(449990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (49, NULL, 1, 15, 1, CAST(399330 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (50, NULL, 59, 73, 7, CAST(777220 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (51, CAST(N'2019-05-04T00:00:00.0000000' AS DateTime2), 78, 14, 7, CAST(172900 AS Decimal(10, 0)), CAST(N'2019-06-04T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (52, CAST(N'2019-10-04T00:00:00.0000000' AS DateTime2), 12, 7, 9, CAST(579800 AS Decimal(10, 0)), CAST(N'2019-11-04T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (53, NULL, 39, 70, 6, CAST(579800 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (54, NULL, 14, 52, 3, CAST(886515 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (55, CAST(N'2019-02-05T00:00:00.0000000' AS DateTime2), 6, 61, 5, CAST(240005 AS Decimal(10, 0)), CAST(N'2019-03-05T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (56, CAST(N'2019-10-05T00:00:00.0000000' AS DateTime2), 4, 79, 7, CAST(24425 AS Decimal(10, 0)), CAST(N'2019-11-05T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (57, NULL, 4, 26, 3, CAST(482900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (58, NULL, 4, 98, 5, CAST(699330 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (59, CAST(N'2019-04-06T00:00:00.0000000' AS DateTime2), 83, 91, 4, CAST(45900 AS Decimal(10, 0)), CAST(N'2019-05-06T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (60, CAST(N'2019-05-06T00:00:00.0000000' AS DateTime2), 6, 22, 4, CAST(74990 AS Decimal(10, 0)), CAST(N'2019-06-06T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (61, NULL, 67, 18, 7, CAST(74990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (62, NULL, 36, 64, 8, CAST(579800 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (63, CAST(N'2019-05-07T00:00:00.0000000' AS DateTime2), 23, 47, 5, CAST(45900 AS Decimal(10, 0)), CAST(N'2019-06-07T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (64, CAST(N'2019-09-07T00:00:00.0000000' AS DateTime2), 84, 50, 1, CAST(451905 AS Decimal(10, 0)), CAST(N'2019-10-07T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (65, NULL, 82, 55, 1, CAST(999990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (66, NULL, 78, 54, 2, CAST(50125 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (67, NULL, 21, 49, 8, CAST(371375 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (68, NULL, 5, 3, 1, CAST(44900 AS Decimal(10, 0)), CAST(N'2019-01-08T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (69, CAST(N'2019-08-08T00:00:00.0000000' AS DateTime2), 75, 22, 7, CAST(191385 AS Decimal(10, 0)), CAST(N'2019-09-08T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (70, CAST(N'2019-12-08T00:00:00.0000000' AS DateTime2), 35, 89, 6, CAST(385270 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (71, NULL, 66, 86, 6, CAST(285000 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (72, NULL, 99, 86, 5, CAST(22425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (73, CAST(N'2019-09-09T00:00:00.0000000' AS DateTime2), 89, 95, 10, CAST(54990 AS Decimal(10, 0)), CAST(N'2019-10-09T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (74, NULL, 59, 40, 8, CAST(74990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (75, NULL, 41, 44, 4, CAST(17425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (76, NULL, 86, 40, 2, CAST(209900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (77, NULL, 3, 80, 4, CAST(285000 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (78, NULL, 20, 17, 1, CAST(769955 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (79, NULL, 49, 87, 6, CAST(547425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (80, CAST(N'2019-03-10T00:00:00.0000000' AS DateTime2), 17, 82, 6, CAST(499900 AS Decimal(10, 0)), CAST(N'2019-04-10T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (81, NULL, 73, 95, 8, CAST(172900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (82, NULL, 15, 48, 6, CAST(449990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (83, CAST(N'2019-09-11T00:00:00.0000000' AS DateTime2), 33, 62, 6, CAST(499890 AS Decimal(10, 0)), CAST(N'2019-10-11T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (84, NULL, 3, 93, 6, CAST(139900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (85, NULL, 62, 86, 4, CAST(379800 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (86, CAST(N'2019-02-12T00:00:00.0000000' AS DateTime2), 38, 10, 2, CAST(141200 AS Decimal(10, 0)), CAST(N'2019-03-12T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (87, CAST(N'2019-05-12T00:00:00.0000000' AS DateTime2), 91, 22, 3, CAST(285000 AS Decimal(10, 0)), CAST(N'2019-06-12T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (88, NULL, 88, 44, 10, CAST(141200 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (89, NULL, 73, 85, 2, CAST(24425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (90, NULL, 68, 54, 2, CAST(10000 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (91, CAST(N'2020-05-01T00:00:00.0000000' AS DateTime2), 72, 15, 2, CAST(172900 AS Decimal(10, 0)), CAST(N'2020-06-01T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (92, NULL, 66, 1, 4, CAST(547425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (93, NULL, 69, 55, 5, CAST(54990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (94, CAST(N'2020-05-02T00:00:00.0000000' AS DateTime2), 1, 70, 5, CAST(319900 AS Decimal(10, 0)), CAST(N'2020-06-02T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (95, CAST(N'2020-10-02T00:00:00.0000000' AS DateTime2), 41, 12, 6, CAST(221385 AS Decimal(10, 0)), CAST(N'2020-11-02T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (96, NULL, 12, 21, 1, CAST(127965 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (97, NULL, 39, 23, 9, CAST(379800 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (98, CAST(N'2020-08-03T00:00:00.0000000' AS DateTime2), 83, 3, 5, CAST(385270 AS Decimal(10, 0)), CAST(N'2020-09-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (99, CAST(N'2020-09-03T00:00:00.0000000' AS DateTime2), 44, 28, 8, CAST(547425 AS Decimal(10, 0)), CAST(N'2020-10-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (100, CAST(N'2020-11-03T00:00:00.0000000' AS DateTime2), 12, 49, 2, CAST(48850 AS Decimal(10, 0)), CAST(N'2020-12-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (101, NULL, 48, 70, 1, CAST(699330 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (102, NULL, 50, 36, 2, CAST(112600 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (103, CAST(N'2020-09-04T00:00:00.0000000' AS DateTime2), 35, 11, 1, CAST(24425 AS Decimal(10, 0)), CAST(N'2020-10-04T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (104, NULL, 70, 18, 2, CAST(191385 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (105, NULL, 31, 5, 4, CAST(285000 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (106, CAST(N'2020-01-05T00:00:00.0000000' AS DateTime2), 8, 38, 4, CAST(518700 AS Decimal(10, 0)), CAST(N'2020-02-05T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (107, CAST(N'2020-09-05T00:00:00.0000000' AS DateTime2), 30, 22, 8, CAST(299890 AS Decimal(10, 0)), CAST(N'2020-10-05T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (108, NULL, 26, 28, 10, CAST(17425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (109, NULL, 11, 76, 4, CAST(17425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (110, NULL, 2, 100, 5, CAST(899900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (111, NULL, 48, 87, 9, CAST(44900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (112, CAST(N'2020-05-07T00:00:00.0000000' AS DateTime2), 81, 33, 9, CAST(74990 AS Decimal(10, 0)), CAST(N'2020-06-07T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (113, NULL, 69, 70, 7, CAST(2439890 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (114, NULL, 76, 67, 10, CAST(769955 AS Decimal(10, 0)), CAST(N'2020-01-08T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (115, CAST(N'2020-12-08T00:00:00.0000000' AS DateTime2), 47, 59, 6, CAST(191385 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (116, NULL, 15, 71, 4, CAST(172900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (117, CAST(N'2020-01-09T00:00:00.0000000' AS DateTime2), 90, 38, 7, CAST(559600 AS Decimal(10, 0)), CAST(N'2020-02-09T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (118, CAST(N'2020-03-09T00:00:00.0000000' AS DateTime2), 48, 65, 9, CAST(999990 AS Decimal(10, 0)), CAST(N'2020-04-09T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (119, NULL, 13, 85, 7, CAST(441375 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (120, NULL, 53, 96, 6, CAST(319900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (121, CAST(N'2020-10-10T00:00:00.0000000' AS DateTime2), 71, 12, 10, CAST(469900 AS Decimal(10, 0)), CAST(N'2020-11-10T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (122, NULL, 4, 51, 7, CAST(999990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (123, CAST(N'2020-03-11T00:00:00.0000000' AS DateTime2), 16, 31, 2, CAST(469900 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (124, NULL, 87, 21, 8, CAST(337800 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (125, NULL, 27, 4, 3, CAST(1086682 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (126, NULL, 14, 15, 1, CAST(685270 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (127, CAST(N'2020-06-12T00:00:00.0000000' AS DateTime2), 58, 35, 2, CAST(685270 AS Decimal(10, 0)), CAST(N'2020-07-12T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (128, CAST(N'2020-12-12T00:00:00.0000000' AS DateTime2), 73, 12, 2, CAST(40125 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (129, NULL, 47, 76, 2, CAST(482900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (130, NULL, 70, 57, 2, CAST(109900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (131, NULL, 80, 26, 7, CAST(109900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (132, CAST(N'2021-06-01T00:00:00.0000000' AS DateTime2), 75, 43, 6, CAST(50125 AS Decimal(10, 0)), CAST(N'2021-07-01T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (133, NULL, 52, 75, 6, CAST(499890 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (134, NULL, 86, 92, 10, CAST(299900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (135, CAST(N'2021-04-02T00:00:00.0000000' AS DateTime2), 10, 24, 9, CAST(1094850 AS Decimal(10, 0)), CAST(N'2021-05-02T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (136, CAST(N'2021-12-02T00:00:00.0000000' AS DateTime2), 96, 15, 1, CAST(799900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (137, NULL, 21, 28, 2, CAST(299890 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (138, CAST(N'2021-04-03T00:00:00.0000000' AS DateTime2), 21, 83, 4, CAST(179980 AS Decimal(10, 0)), CAST(N'2021-05-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (139, CAST(N'2021-10-03T00:00:00.0000000' AS DateTime2), 76, 82, 5, CAST(579800 AS Decimal(10, 0)), CAST(N'2021-11-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (140, CAST(N'2021-12-03T00:00:00.0000000' AS DateTime2), 27, 41, 9, CAST(179980 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (141, NULL, 74, 74, 8, CAST(547425 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (142, NULL, 12, 47, 2, CAST(434610 AS Decimal(10, 0)), CAST(N'2021-01-04T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (143, CAST(N'2021-05-04T00:00:00.0000000' AS DateTime2), 49, 53, 4, CAST(371375 AS Decimal(10, 0)), CAST(N'2021-06-04T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (144, CAST(N'2021-11-04T00:00:00.0000000' AS DateTime2), 57, 73, 9, CAST(139900 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (145, NULL, 2, 31, 6, CAST(139900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (146, NULL, 10, 5, 1, CAST(685270 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (147, NULL, 77, 57, 9, CAST(249900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (148, CAST(N'2021-08-05T00:00:00.0000000' AS DateTime2), 6, 41, 10, CAST(762850 AS Decimal(10, 0)), CAST(N'2021-09-05T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (149, NULL, 9, 63, 7, CAST(769955 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (150, NULL, 27, 34, 6, CAST(299890 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (151, CAST(N'2021-03-06T00:00:00.0000000' AS DateTime2), 84, 96, 6, CAST(592470 AS Decimal(10, 0)), CAST(N'2021-04-06T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (152, CAST(N'2021-07-06T00:00:00.0000000' AS DateTime2), 63, 88, 2, CAST(249900 AS Decimal(10, 0)), CAST(N'2021-08-06T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (153, CAST(N'2021-11-06T00:00:00.0000000' AS DateTime2), 39, 7, 3, CAST(10000 AS Decimal(10, 0)), CAST(N'2021-12-06T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (154, NULL, 8, 22, 10, CAST(1207425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (155, NULL, 60, 12, 2, CAST(299900 AS Decimal(10, 0)), CAST(N'2021-01-07T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (156, CAST(N'2021-07-07T00:00:00.0000000' AS DateTime2), 39, 70, 10, CAST(149925 AS Decimal(10, 0)), CAST(N'2021-08-07T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (157, NULL, 21, 76, 3, CAST(172900 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (158, NULL, 9, 88, 4, CAST(50125 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (159, NULL, 16, 18, 5, CAST(50125 AS Decimal(10, 0)), CAST(N'2021-01-08T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (160, NULL, 71, 71, 2, CAST(22425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (161, NULL, 82, 79, 2, CAST(131190 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (162, NULL, 87, 25, 1, CAST(455803 AS Decimal(10, 0)), CAST(N'2021-01-09T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (163, NULL, 68, 28, 4, CAST(379800 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (164, NULL, 75, 86, 7, CAST(1219945 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (165, CAST(N'2021-10-10T00:00:00.0000000' AS DateTime2), 3, 65, 6, CAST(699330 AS Decimal(10, 0)), CAST(N'2021-11-10T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (166, NULL, 36, 19, 10, CAST(22425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (167, NULL, 58, 58, 2, CAST(249900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (168, NULL, 33, 98, 1, CAST(449990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (169, CAST(N'2021-05-11T00:00:00.0000000' AS DateTime2), 52, 15, 1, CAST(101175 AS Decimal(10, 0)), CAST(N'2021-06-11T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (170, CAST(N'2021-07-11T00:00:00.0000000' AS DateTime2), 53, 46, 4, CAST(579800 AS Decimal(10, 0)), CAST(N'2021-08-11T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (171, NULL, 96, 88, 5, CAST(131190 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (172, NULL, 78, 58, 7, CAST(385270 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (173, CAST(N'2021-06-12T00:00:00.0000000' AS DateTime2), 29, 32, 3, CAST(499900 AS Decimal(10, 0)), CAST(N'2021-07-12T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (174, CAST(N'2021-08-12T00:00:00.0000000' AS DateTime2), 86, 95, 4, CAST(112600 AS Decimal(10, 0)), CAST(N'2021-09-12T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (175, NULL, 25, 67, 6, CAST(350781 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (176, NULL, 16, 4, 4, CAST(155610 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (177, NULL, 100, 83, 3, CAST(798660 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (178, NULL, 57, 79, 9, CAST(101175 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (179, NULL, 20, 73, 8, CAST(44900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (180, CAST(N'2022-02-02T00:00:00.0000000' AS DateTime2), 14, 38, 8, CAST(382770 AS Decimal(10, 0)), CAST(N'2022-03-02T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (181, CAST(N'2022-07-02T00:00:00.0000000' AS DateTime2), 63, 80, 1, CAST(371375 AS Decimal(10, 0)), CAST(N'2022-08-02T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (182, NULL, 74, 14, 10, CAST(385270 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (183, NULL, 7, 55, 7, CAST(319900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (184, CAST(N'2022-04-03T00:00:00.0000000' AS DateTime2), 100, 93, 2, CAST(24425 AS Decimal(10, 0)), CAST(N'2022-05-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (185, CAST(N'2022-10-03T00:00:00.0000000' AS DateTime2), 65, 26, 5, CAST(50125 AS Decimal(10, 0)), CAST(N'2022-11-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (186, NULL, 95, 49, 9, CAST(17425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (187, NULL, 30, 86, 10, CAST(10000 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (188, NULL, 2, 19, 4, CAST(399330 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (189, CAST(N'2022-01-04T00:00:00.0000000' AS DateTime2), 10, 11, 8, CAST(109900 AS Decimal(10, 0)), CAST(N'2022-02-04T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (190, CAST(N'2022-11-04T00:00:00.0000000' AS DateTime2), 35, 60, 10, CAST(882750 AS Decimal(10, 0)), CAST(N'2022-12-04T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (191, NULL, 6, 97, 2, CAST(112600 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (192, NULL, 76, 53, 4, CAST(249900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (193, CAST(N'2022-03-05T00:00:00.0000000' AS DateTime2), 99, 24, 5, CAST(249900 AS Decimal(10, 0)), CAST(N'2022-04-05T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (194, NULL, 57, 28, 10, CAST(469900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (195, NULL, 95, 38, 9, CAST(799900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (196, CAST(N'2022-04-06T00:00:00.0000000' AS DateTime2), 92, 4, 7, CAST(179980 AS Decimal(10, 0)), CAST(N'2022-05-06T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (197, CAST(N'2022-07-06T00:00:00.0000000' AS DateTime2), 93, 71, 7, CAST(249900 AS Decimal(10, 0)), CAST(N'2022-08-06T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (198, NULL, 93, 51, 7, CAST(299890 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (199, CAST(N'2022-01-07T00:00:00.0000000' AS DateTime2), 53, 88, 5, CAST(1765500 AS Decimal(10, 0)), CAST(N'2022-02-07T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (200, CAST(N'2022-05-07T00:00:00.0000000' AS DateTime2), 81, 85, 10, CAST(379800 AS Decimal(10, 0)), CAST(N'2022-06-07T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (201, NULL, 83, 97, 6, CAST(685270 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (202, NULL, 83, 8, 3, CAST(319900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (203, NULL, 23, 80, 7, CAST(252787 AS Decimal(10, 0)), CAST(N'2022-01-08T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (204, CAST(N'2022-03-08T00:00:00.0000000' AS DateTime2), 97, 25, 8, CAST(379800 AS Decimal(10, 0)), CAST(N'2022-04-08T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (205, NULL, 5, 54, 9, CAST(762850 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (206, NULL, 64, 58, 1, CAST(385270 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (207, NULL, 33, 77, 3, CAST(409800 AS Decimal(10, 0)), CAST(N'2022-01-09T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (208, CAST(N'2022-08-09T00:00:00.0000000' AS DateTime2), 66, 50, 9, CAST(172900 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (209, NULL, 31, 37, 3, CAST(499890 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (210, NULL, 50, 91, 2, CAST(777220 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (211, CAST(N'2022-02-10T00:00:00.0000000' AS DateTime2), 4, 19, 6, CAST(22425 AS Decimal(10, 0)), CAST(N'2022-03-10T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (212, NULL, 69, 87, 10, CAST(22425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (213, NULL, 76, 56, 2, CAST(882750 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (214, NULL, 32, 4, 1, CAST(240005 AS Decimal(10, 0)), CAST(N'2022-01-11T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (215, CAST(N'2022-02-11T00:00:00.0000000' AS DateTime2), 46, 6, 1, CAST(149925 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (216, NULL, 72, 71, 5, CAST(399330 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (217, NULL, 50, 38, 5, CAST(799900 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (218, CAST(N'2022-03-12T00:00:00.0000000' AS DateTime2), 17, 59, 3, CAST(209900 AS Decimal(10, 0)), CAST(N'2022-04-12T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (219, CAST(N'2022-11-12T00:00:00.0000000' AS DateTime2), 24, 57, 1, CAST(22425 AS Decimal(10, 0)), CAST(N'2022-12-12T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (220, NULL, 93, 53, 5, CAST(1219945 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (221, NULL, 53, 59, 10, CAST(999990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (222, CAST(N'2023-01-01T00:00:00.0000000' AS DateTime2), 92, 89, 8, CAST(499890 AS Decimal(10, 0)), CAST(N'2023-02-01T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (223, NULL, 60, 5, 6, CAST(449990 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (224, NULL, 74, 20, 7, CAST(141200 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (225, NULL, 43, 44, 3, CAST(2288550 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (226, CAST(N'2023-03-02T00:00:00.0000000' AS DateTime2), 73, 86, 4, CAST(1219945 AS Decimal(10, 0)), CAST(N'2023-04-02T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (227, NULL, 40, 19, 4, CAST(762850 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (228, NULL, 38, 5, 6, CAST(399330 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (229, NULL, 17, 54, 7, CAST(22425 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (230, CAST(N'2023-10-03T00:00:00.0000000' AS DateTime2), 49, 27, 7, CAST(499890 AS Decimal(10, 0)), CAST(N'2023-11-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (231, CAST(N'2023-11-03T00:00:00.0000000' AS DateTime2), 94, 42, 2, CAST(570000 AS Decimal(10, 0)), CAST(N'2023-12-03T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (232, NULL, 28, 47, 2, CAST(101175 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (233, NULL, 91, 78, 10, CAST(10000 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (234, NULL, 73, 83, 9, CAST(44900 AS Decimal(10, 0)), CAST(N'2023-01-04T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (235, CAST(N'2023-05-04T00:00:00.0000000' AS DateTime2), 26, 40, 8, CAST(40125 AS Decimal(10, 0)), CAST(N'2023-06-04T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (236, CAST(N'2023-08-04T00:00:00.0000000' AS DateTime2), 7, 28, 5, CAST(101175 AS Decimal(10, 0)), CAST(N'2023-09-04T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (237, NULL, 61, 21, 10, CAST(399330 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (238, NULL, 97, 94, 5, CAST(299900 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (239, CAST(N'2023-01-05T00:00:00.0000000' AS DateTime2), 30, 53, 4, CAST(101175 AS Decimal(10, 0)), CAST(N'2023-02-05T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (240, CAST(N'2023-12-05T00:00:00.0000000' AS DateTime2), 17, 5, 1, CAST(1525700 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (241, NULL, 54, 6, 9, CAST(777220 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (242, NULL, 71, 33, 8, CAST(777220 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (243, CAST(N'2023-05-06T00:00:00.0000000' AS DateTime2), 72, 72, 7, CAST(74990 AS Decimal(10, 0)), CAST(N'2023-06-06T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (244, NULL, 33, 68, 4, CAST(109900 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (245, NULL, 10, 82, 3, CAST(221385 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (246, CAST(N'2023-03-07T00:00:00.0000000' AS DateTime2), 92, 45, 6, CAST(574155 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (247, CAST(N'2023-05-07T00:00:00.0000000' AS DateTime2), 71, 77, 6, CAST(2007325 AS Decimal(10, 0)), CAST(N'2023-06-07T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (248, NULL, 77, 100, 9, CAST(699330 AS Decimal(10, 0)), NULL, 1)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (249, NULL, 96, 99, 1, CAST(109900 AS Decimal(10, 0)), NULL, 0)
GO
INSERT [dbo].[ELEFacturaEnc] ([NumFactura], [FecCompra], [CodCliente], [CodEmpleado], [CodTienda], [Total], [FecEntrega], [Estado]) VALUES (250, CAST(N'2023-09-08T00:00:00.0000000' AS DateTime2), 67, 91, 1, CAST(1709100 AS Decimal(10, 0)), CAST(N'2023-10-08T00:00:00.0000000' AS DateTime2), 1)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (1, 1, 1, CAST(1207425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 38)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (2, 1, 1, CAST(1219945 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 34)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (3, 1, 1, CAST(1219945 AS Decimal(10, 0)), CAST(36598 AS Decimal(10, 0)), 34)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (4, 1, 3, CAST(499900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 48)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (5, 1, 1, CAST(385270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 1)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (6, 1, 1, CAST(240005 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 30)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (7, 1, 1, CAST(685270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 37)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (8, 1, 1, CAST(44900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 24)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (9, 1, 2, CAST(350781 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 39)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (10, 1, 1, CAST(240005 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 30)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (11, 1, 1, CAST(17425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 43)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (12, 1, 1, CAST(22425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 7)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (13, 1, 1, CAST(131190 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 51)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (14, 1, 1, CAST(34425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 6)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (15, 1, 1, CAST(499890 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 5)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (16, 1, 1, CAST(54990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 14)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (17, 1, 3, CAST(54990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 14)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (18, 1, 1, CAST(101175 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 16)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (19, 1, 1, CAST(149925 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 32)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (20, 1, 1, CAST(385270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 1)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (21, 1, 1, CAST(44900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 24)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (22, 1, 1, CAST(285000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 26)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (23, 1, 1, CAST(209900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 47)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (24, 1, 1, CAST(101175 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 16)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (25, 1, 1, CAST(109900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 12)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (26, 1, 1, CAST(899900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 50)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (27, 1, 1, CAST(22425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 7)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (28, 1, 1, CAST(191385 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 54)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (29, 1, 1, CAST(371375 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 55)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (30, 1, 1, CAST(139900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 11)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (31, 1, 1, CAST(399330 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 40)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (32, 1, 3, CAST(999990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 36)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (33, 1, 1, CAST(350781 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 39)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (34, 1, 1, CAST(10000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 25)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (35, 1, 1, CAST(451905 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 29)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (36, 1, 2, CAST(371375 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 55)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (37, 1, 1, CAST(17425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 43)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (38, 1, 1, CAST(40125 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 17)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (39, 1, 1, CAST(249900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 44)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (40, 1, 2, CAST(74990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 49)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (41, 1, 1, CAST(285000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 26)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (42, 1, 1, CAST(449990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 28)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (43, 1, 1, CAST(899900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 50)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (44, 1, 3, CAST(141200 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 9)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (45, 1, 1, CAST(40125 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 17)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (46, 1, 1, CAST(482900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 27)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (47, 1, 1, CAST(385270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 1)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (48, 1, 1, CAST(449990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 28)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (49, 1, 1, CAST(399330 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 40)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (50, 1, 1, CAST(777220 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 3)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (51, 1, 1, CAST(172900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 10)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (52, 1, 1, CAST(579800 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 53)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (53, 1, 1, CAST(579800 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 53)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (54, 1, 1, CAST(482900 AS Decimal(10, 0)), CAST(48290 AS Decimal(10, 0)), 27)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (54, 2, 1, CAST(451905 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 29)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (55, 1, 1, CAST(240005 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 30)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (56, 1, 1, CAST(24425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 42)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (57, 1, 1, CAST(482900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 27)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (58, 1, 1, CAST(699330 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 4)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (59, 1, 1, CAST(45900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 22)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (60, 1, 1, CAST(74990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 49)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (61, 1, 1, CAST(74990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 49)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (62, 1, 1, CAST(579800 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 53)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (63, 1, 1, CAST(45900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 22)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (64, 1, 1, CAST(451905 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 29)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (65, 1, 1, CAST(999990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 36)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (66, 1, 1, CAST(50125 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 52)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (67, 1, 1, CAST(371375 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 55)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (68, 1, 1, CAST(44900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 24)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (69, 1, 1, CAST(191385 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 54)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (70, 1, 1, CAST(385270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 1)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (71, 1, 1, CAST(285000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 26)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (72, 1, 1, CAST(22425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 7)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (73, 1, 1, CAST(54990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 14)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (74, 1, 1, CAST(74990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 49)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (75, 1, 1, CAST(17425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 43)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (76, 1, 1, CAST(209900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 47)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (77, 1, 1, CAST(285000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 26)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (78, 1, 1, CAST(769955 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 35)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (79, 1, 1, CAST(547425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 2)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (80, 1, 1, CAST(499900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 48)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (81, 1, 1, CAST(172900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 10)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (82, 1, 1, CAST(449990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 28)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (83, 1, 1, CAST(499890 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 5)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (84, 1, 1, CAST(139900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 11)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (85, 1, 1, CAST(379800 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 18)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (86, 1, 1, CAST(141200 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 9)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (87, 1, 1, CAST(285000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 26)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (88, 1, 1, CAST(141200 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 9)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (89, 1, 1, CAST(24425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 42)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (90, 1, 1, CAST(10000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 25)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (91, 1, 1, CAST(172900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 10)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (92, 1, 1, CAST(547425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 2)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (93, 1, 1, CAST(54990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 14)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (94, 1, 1, CAST(319900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 21)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (95, 1, 1, CAST(221385 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 19)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (96, 1, 3, CAST(44900 AS Decimal(10, 0)), CAST(6735 AS Decimal(10, 0)), 24)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (97, 1, 1, CAST(379800 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 18)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (98, 1, 1, CAST(385270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 1)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (99, 1, 1, CAST(547425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 2)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (100, 1, 2, CAST(24425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 42)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (101, 1, 1, CAST(699330 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 4)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (102, 1, 1, CAST(112600 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 45)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (103, 1, 1, CAST(24425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 42)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (104, 1, 1, CAST(191385 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 54)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (105, 1, 1, CAST(285000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 26)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (106, 1, 3, CAST(172900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 10)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (107, 1, 1, CAST(299890 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 41)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (108, 1, 1, CAST(17425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 43)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (109, 1, 1, CAST(17425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 43)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (110, 1, 1, CAST(899900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 50)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (111, 1, 1, CAST(44900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 24)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (112, 1, 1, CAST(74990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 49)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (113, 1, 2, CAST(1219945 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 34)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (114, 1, 1, CAST(769955 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 35)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (115, 1, 1, CAST(191385 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 54)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (116, 1, 1, CAST(172900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 10)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (117, 1, 4, CAST(139900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 11)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (118, 1, 1, CAST(999990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 36)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (119, 1, 1, CAST(441375 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 20)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (120, 1, 1, CAST(319900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 21)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (121, 1, 1, CAST(469900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 8)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (122, 1, 1, CAST(999990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 36)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (123, 1, 1, CAST(469900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 8)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (124, 1, 3, CAST(112600 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 45)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (125, 1, 1, CAST(1207425 AS Decimal(10, 0)), CAST(120742 AS Decimal(10, 0)), 38)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (126, 1, 1, CAST(685270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 37)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (127, 1, 1, CAST(685270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 37)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (128, 1, 1, CAST(40125 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 17)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (129, 1, 1, CAST(482900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 27)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (130, 1, 1, CAST(109900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 12)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (131, 1, 1, CAST(109900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 12)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (132, 1, 1, CAST(50125 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 52)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (133, 1, 1, CAST(499890 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 5)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (134, 1, 1, CAST(299900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 13)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (135, 1, 2, CAST(547425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 2)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (136, 1, 1, CAST(799900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 15)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (137, 1, 1, CAST(299890 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 41)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (138, 1, 1, CAST(179980 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 46)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (139, 1, 1, CAST(579800 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 53)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (140, 1, 1, CAST(179980 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 46)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (141, 1, 1, CAST(547425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 2)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (142, 1, 1, CAST(482900 AS Decimal(10, 0)), CAST(48290 AS Decimal(10, 0)), 27)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (143, 1, 1, CAST(371375 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 55)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (144, 1, 1, CAST(139900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 11)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (145, 1, 1, CAST(139900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 11)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (146, 1, 1, CAST(685270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 37)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (147, 1, 1, CAST(249900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 44)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (148, 1, 1, CAST(762850 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 31)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (149, 1, 1, CAST(769955 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 35)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (150, 1, 1, CAST(299890 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 41)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (151, 1, 1, CAST(299890 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 41)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (151, 2, 1, CAST(112600 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 45)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (151, 3, 1, CAST(179980 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 46)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (152, 1, 1, CAST(249900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 44)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (153, 1, 1, CAST(10000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 25)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (154, 1, 1, CAST(1207425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 38)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (155, 1, 1, CAST(299900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 13)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (156, 1, 1, CAST(149925 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 32)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (157, 1, 1, CAST(172900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 10)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (158, 1, 1, CAST(50125 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 52)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (159, 1, 1, CAST(50125 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 52)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (160, 1, 1, CAST(22425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 7)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (161, 1, 1, CAST(131190 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 51)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (162, 1, 1, CAST(469900 AS Decimal(10, 0)), CAST(14097 AS Decimal(10, 0)), 8)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (163, 1, 1, CAST(379800 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 18)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (164, 1, 1, CAST(1219945 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 34)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (165, 1, 1, CAST(699330 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 4)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (166, 1, 1, CAST(22425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 7)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (167, 1, 1, CAST(249900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 44)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (168, 1, 1, CAST(449990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 28)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (169, 1, 1, CAST(101175 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 16)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (170, 1, 1, CAST(579800 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 53)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (171, 1, 1, CAST(131190 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 51)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (172, 1, 1, CAST(385270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 1)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (173, 1, 1, CAST(499900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 48)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (174, 1, 1, CAST(112600 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 45)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (175, 1, 1, CAST(350781 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 39)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (176, 1, 1, CAST(172900 AS Decimal(10, 0)), CAST(17290 AS Decimal(10, 0)), 10)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (177, 1, 2, CAST(399330 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 40)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (178, 1, 1, CAST(101175 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 16)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (179, 1, 1, CAST(44900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 24)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (180, 1, 2, CAST(191385 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 54)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (181, 1, 1, CAST(371375 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 55)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (182, 1, 1, CAST(385270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 1)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (183, 1, 1, CAST(319900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 21)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (184, 1, 1, CAST(24425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 42)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (185, 1, 1, CAST(50125 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 52)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (186, 1, 1, CAST(17425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 43)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (187, 1, 1, CAST(10000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 25)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (188, 1, 1, CAST(399330 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 40)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (189, 1, 1, CAST(109900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 12)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (190, 1, 2, CAST(441375 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 20)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (191, 1, 1, CAST(112600 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 45)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (192, 1, 1, CAST(249900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 44)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (193, 1, 1, CAST(249900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 44)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (194, 1, 1, CAST(469900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 8)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (195, 1, 1, CAST(799900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 15)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (196, 1, 1, CAST(179980 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 46)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (197, 1, 1, CAST(249900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 44)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (198, 1, 1, CAST(299890 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 41)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (199, 1, 4, CAST(441375 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 20)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (200, 1, 1, CAST(379800 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 18)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (201, 1, 1, CAST(685270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 37)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (202, 1, 1, CAST(319900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 21)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (203, 1, 7, CAST(40125 AS Decimal(10, 0)), CAST(28087 AS Decimal(10, 0)), 17)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (204, 1, 1, CAST(379800 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 18)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (205, 1, 1, CAST(762850 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 31)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (206, 1, 1, CAST(385270 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 1)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (207, 1, 1, CAST(109900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 12)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (207, 2, 1, CAST(299900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 13)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (208, 1, 1, CAST(172900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 10)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (209, 1, 1, CAST(499890 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 5)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (210, 1, 1, CAST(777220 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 3)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (211, 1, 1, CAST(22425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 7)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (212, 1, 1, CAST(22425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 7)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (213, 1, 2, CAST(441375 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 20)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (214, 1, 1, CAST(240005 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 30)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (215, 1, 1, CAST(149925 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 32)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (216, 1, 1, CAST(399330 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 40)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (217, 1, 1, CAST(799900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 15)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (218, 1, 1, CAST(209900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 47)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (219, 1, 1, CAST(22425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 7)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (220, 1, 1, CAST(1219945 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 34)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (221, 1, 1, CAST(999990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 36)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (222, 1, 1, CAST(499890 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 5)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (223, 1, 1, CAST(449990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 28)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (224, 1, 1, CAST(141200 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 9)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (225, 1, 3, CAST(762850 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 31)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (226, 1, 1, CAST(1219945 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 34)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (227, 1, 1, CAST(762850 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 31)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (228, 1, 1, CAST(399330 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 40)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (229, 1, 1, CAST(22425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 7)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (230, 1, 1, CAST(499890 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 5)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (231, 1, 2, CAST(285000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 26)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (232, 1, 1, CAST(101175 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 16)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (233, 1, 1, CAST(10000 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 25)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (234, 1, 1, CAST(44900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 24)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (235, 1, 1, CAST(40125 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 17)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (236, 1, 1, CAST(101175 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 16)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (237, 1, 1, CAST(399330 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 40)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (238, 1, 1, CAST(299900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 33)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (239, 1, 1, CAST(101175 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 16)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (240, 1, 2, CAST(762850 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 31)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (241, 1, 1, CAST(777220 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 3)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (242, 1, 1, CAST(777220 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 3)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (243, 1, 1, CAST(74990 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 49)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (244, 1, 1, CAST(109900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 12)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (245, 1, 1, CAST(221385 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 19)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (246, 1, 3, CAST(191385 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 54)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (247, 1, 1, CAST(799900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 15)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (247, 2, 1, CAST(1207425 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 38)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (248, 1, 1, CAST(699330 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 4)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (249, 1, 1, CAST(109900 AS Decimal(10, 0)), CAST(0 AS Decimal(10, 0)), 12)
GO
INSERT [dbo].[ELEFacturasDet] ([NumFactura], [CodItem], [Cantidad], [PrecioUnitario], [Descuento], [CodProducto]) VALUES (250, 1, 5, CAST(379800 AS Decimal(10, 0)), CAST(189900 AS Decimal(10, 0)), 18)
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (1, N'Hatlas')
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (2, N'Zamzung')
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (3, N'Toshiwa')
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (4, N'Total Electric')
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (5, N'White House')
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (6, N'Jamilton B')
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (7, N'Friyiday')
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (8, N'Rumba')
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (9, N'Blak y Deck')
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (10, N'Durabán')
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (11, N'Guirpul')
GO
INSERT [dbo].[ELEMarcas] ([CodMarca], [Descripcion]) VALUES (12, N'Mabi')
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (1, N'Refrigeradora Friyiday Top Freezer 15 pies', CAST(385270 AS Decimal(10, 0)), 7, 6)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (2, N'Refrigeradora Friyiday Side by Side No Frost 18.7 pies', CAST(547425 AS Decimal(10, 0)), 7, 6)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (3, N'Refrigeradora Zamzung Side by side No Frost 22 pies', CAST(777220 AS Decimal(10, 0)), 2, 6)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (4, N'Lavadora Zamzung Frontal 24 Kg WF8800A', CAST(699330 AS Decimal(10, 0)), 2, 4)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (5, N'Lavadora Automática Friyiday 25 Kg', CAST(499890 AS Decimal(10, 0)), 7, 4)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (6, N'Batidora Total Electric 220 W Blanco HM50', CAST(34425 AS Decimal(10, 0)), 4, 7)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (7, N'Batidora Jamilton B 64654 250W 3.8 L Rojo', CAST(22425 AS Decimal(10, 0)), 6, 7)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (8, N'Batidora de Pedestal White House 7QT KSM70SKXXER', CAST(469900 AS Decimal(10, 0)), 5, 7)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (9, N'Congelador Friyiday Horizontal 5 Pies', CAST(141200 AS Decimal(10, 0)), 7, 9)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (10, N'Congelador Total Electric Horizontal 145 L RFC-580', CAST(172900 AS Decimal(10, 0)), 4, 9)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (11, N'Microondas Toshiwa NN-SC649SRFH 1.0 ft3 Plateado', CAST(139900 AS Decimal(10, 0)), 3, 5)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (12, N'Microondas Zamzung MG28F303TAS 1.0 ft3', CAST(109900 AS Decimal(10, 0)), 2, 5)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (13, N'Cocina Hatlas 4 quemadores EAE5020BSS0', CAST(299900 AS Decimal(10, 0)), 1, 2)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (14, N'Plantilla Gas Hatlas 4 Quemadores CA20T-BB-X0', CAST(54990 AS Decimal(10, 0)), 1, 2)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (15, N'Cocina a gas Zamzung 5 Quemadores', CAST(799900 AS Decimal(10, 0)), 2, 2)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (16, N'Procesador de alimentos Jamiltom B FP8SVP1 350 W', CAST(101175 AS Decimal(10, 0)), 6, 8)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (17, N'Procesador de alimentos Blak and Dek HC300B', CAST(40125 AS Decimal(10, 0)), 9, 8)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (18, N'Batidora con tazón White House KSM150PSOB 325W', CAST(379800 AS Decimal(10, 0)), 5, 7)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (19, N'Pantalla Smart Toshiwai TV055XIA14 FHD 55 pulgadas', CAST(221385 AS Decimal(10, 0)), 3, 11)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (20, N'Pantalla Zamzung EHQ65MDUA HQLED de 65 pulgadas', CAST(441375 AS Decimal(10, 0)), 2, 11)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (21, N'Pantalla LED 4K UHD Toshiwa modelo A PRO -55 Pulgadas', CAST(319900 AS Decimal(10, 0)), 3, 11)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (22, N'Freidora de aire Total ElectricXL™ Vortex Pro, AF-E6001-LA -5.7L', CAST(45900 AS Decimal(10, 0)), 4, 1)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (23, N'Pantalla Durabán EHQ65MDUA HQLED de 65 pulgadas', CAST(474900 AS Decimal(10, 0)), 10, 11)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (24, N'Microondas Durabán 0.7 pc EM720CGA PW', CAST(44900 AS Decimal(10, 0)), 10, 5)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (25, N'Leap Frog Tostadora Durabán Colores Y Numeros', CAST(10000 AS Decimal(10, 0)), 10, 12)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (26, N'Lavaplatos Guirpul Inox 14 Servicios', CAST(285000 AS Decimal(10, 0)), 11, 3)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (27, N'Secadora Eléctrica Guipul Frontal 23 KG 7MWED6605MC', CAST(482900 AS Decimal(10, 0)), 11, 13)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (28, N'Secadora Eléctrica General Electric Frontal 22 KG SGE47N5XSBH0', CAST(449990 AS Decimal(10, 0)), 4, 13)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (29, N'Lavadora Zamzung Frontal 20 Kg WF20T6000AW', CAST(451905 AS Decimal(10, 0)), 2, 4)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (30, N'Lavadora Mabi Superior 16 Kg LMA76102CBAB0', CAST(240005 AS Decimal(10, 0)), 12, 4)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (31, N'Lavaplatos Friyiday 14 cubiertos Professional', CAST(762850 AS Decimal(10, 0)), 7, 3)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (32, N'Aspiradora Rumba 33 v Negro Combo Y', CAST(149925 AS Decimal(10, 0)), 8, 10)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (33, N'Aspiradora Rumba 33 v Negro Combo i5', CAST(299900 AS Decimal(10, 0)), 8, 10)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (34, N'Centro de Lavado Zamzung Frontal 22 kg Laundry Hub', CAST(1219945 AS Decimal(10, 0)), 2, 14)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (35, N'Centro de Lavado Mabi Superior 20 Kg MCL2040PSBB0', CAST(769955 AS Decimal(10, 0)), 2, 14)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (36, N'Centro de Lavado a Gas Mabi Superior 20 Kg MCL2040PSDG0', CAST(999990 AS Decimal(10, 0)), 12, 4)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (37, N'Refrigeradora Friyiday Top Freezer 20 pies', CAST(685270 AS Decimal(10, 0)), 7, 6)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (38, N'Refrigeradora Friyiday Side by Side No Frost 27.7 pies', CAST(1207425 AS Decimal(10, 0)), 7, 6)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (39, N'Refrigeradora Zamzung Side by side No Frost 14 pies', CAST(350781 AS Decimal(10, 0)), 2, 6)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (40, N'Lavadora Zamzung Frontal 16 Kg WF4000L', CAST(399330 AS Decimal(10, 0)), 2, 4)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (41, N'Lavadora Automática Friyiday 15 Kg', CAST(299890 AS Decimal(10, 0)), 7, 4)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (42, N'Batidora Total Electric 320 W Blanco HM70', CAST(24425 AS Decimal(10, 0)), 4, 7)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (43, N'Batidora Jamilton B 7845 250W 2.8 L Rojo', CAST(17425 AS Decimal(10, 0)), 6, 7)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (44, N'Batidora de Pedestal White House 4QT KSM70SKXZZR', CAST(249900 AS Decimal(10, 0)), 5, 7)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (45, N'Congelador Total Electric Horizontal 125 L RFh-380', CAST(112600 AS Decimal(10, 0)), 4, 9)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (46, N'Microondas Toshiwa NN-SC649SQUL 2.0 ft3 Plateado', CAST(179980 AS Decimal(10, 0)), 3, 5)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (47, N'Microondas Zamzung HG28F30W23 1.0 ft3', CAST(209900 AS Decimal(10, 0)), 2, 5)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (48, N'Cocina Hatlas 6 quemadores EAE6020BSS0', CAST(499900 AS Decimal(10, 0)), 1, 2)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (49, N'Plantilla Gas Hatlas 4 Quemadores CB20T-KK-T6', CAST(74990 AS Decimal(10, 0)), 1, 2)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (50, N'Cocina a gas Zamzung 5 Quemadores MOD YU', CAST(899900 AS Decimal(10, 0)), 2, 2)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (51, N'Procesador de alimentos Jamiltom B TP8SBP1 450 W', CAST(131190 AS Decimal(10, 0)), 6, 8)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (52, N'Procesador de alimentos Blak and Dek HC500B', CAST(50125 AS Decimal(10, 0)), 9, 8)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (53, N'Batidora con tazón White House KSM150HSOB 425W', CAST(579800 AS Decimal(10, 0)), 5, 7)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (54, N'Pantalla Smart Toshiwai TV045XIA14 FHD 45 pulgadas', CAST(191385 AS Decimal(10, 0)), 3, 11)
GO
INSERT [dbo].[ELEProductos] ([CodProducto], [Descripcion], [Precio], [CodMarca], [CodCategoria]) VALUES (55, N'Pantalla Zamzung EHQ60 HQLED de 60 pulgadas', CAST(371375 AS Decimal(10, 0)), 2, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 1, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 2, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 3, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 4, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 5, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 6, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 7, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 8, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 9, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 10, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 11, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 12, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 13, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 14, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 15, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 16, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 17, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 18, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 19, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 20, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 21, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 22, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 23, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 24, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 25, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 26, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 27, 20)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 28, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 29, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 30, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 31, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 32, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 33, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 34, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 35, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 36, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 37, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 38, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 39, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 40, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 41, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 42, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 43, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 44, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 45, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 46, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 47, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 48, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 49, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 50, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 51, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 52, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 53, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 54, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (1, 55, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 1, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 2, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 3, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 4, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 5, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 6, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 7, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 8, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 9, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 10, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 11, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 12, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 13, 20)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 14, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 15, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 16, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 17, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 18, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 19, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 20, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 21, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 22, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 23, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 24, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 25, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 26, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 27, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 28, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 29, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 30, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 31, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 32, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 33, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 34, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 35, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 36, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 37, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 38, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 39, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 40, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 41, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 42, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 43, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 44, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 45, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 46, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 47, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 48, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 49, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 50, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 51, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 52, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 53, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 54, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (2, 55, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 1, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 2, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 3, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 4, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 5, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 6, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 7, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 8, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 9, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 10, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 11, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 12, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 13, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 14, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 15, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 16, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 17, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 18, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 19, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 20, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 21, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 22, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 23, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 24, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 25, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 26, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 27, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 28, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 29, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 30, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 31, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 32, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 33, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 34, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 35, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 36, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 37, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 38, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 39, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 40, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 41, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 42, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 43, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 44, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 45, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 46, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 47, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 48, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 49, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 50, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 51, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 52, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 53, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 54, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (3, 55, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 1, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 2, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 3, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 4, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 5, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 6, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 7, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 8, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 9, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 10, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 11, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 12, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 13, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 14, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 15, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 16, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 17, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 18, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 19, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 20, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 21, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 22, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 23, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 24, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 25, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 26, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 27, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 28, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 29, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 30, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 31, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 32, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 33, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 34, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 35, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 36, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 37, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 38, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 39, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 40, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 41, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 42, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 43, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 44, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 45, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 46, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 47, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 48, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 49, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 50, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 51, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 52, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 53, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 54, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (4, 55, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 1, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 2, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 3, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 4, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 5, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 6, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 7, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 8, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 9, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 10, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 11, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 12, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 13, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 14, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 15, 20)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 16, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 17, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 18, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 19, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 20, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 21, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 22, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 23, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 24, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 25, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 26, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 27, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 28, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 29, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 30, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 31, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 32, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 33, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 34, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 35, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 36, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 37, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 38, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 39, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 40, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 41, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 42, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 43, 20)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 44, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 45, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 46, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 47, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 48, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 49, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 50, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 51, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 52, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 53, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 54, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (5, 55, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 1, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 2, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 3, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 4, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 5, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 6, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 7, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 8, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 9, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 10, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 11, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 12, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 13, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 14, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 15, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 16, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 17, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 18, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 19, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 20, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 21, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 22, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 23, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 24, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 25, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 26, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 27, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 28, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 29, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 30, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 31, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 32, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 33, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 34, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 35, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 36, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 37, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 38, 20)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 39, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 40, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 41, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 42, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 43, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 44, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 45, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 46, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 47, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 48, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 49, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 50, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 51, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 52, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 53, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 54, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (6, 55, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 1, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 2, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 3, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 4, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 5, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 6, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 7, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 8, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 9, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 10, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 11, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 12, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 13, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 14, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 15, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 16, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 17, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 18, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 19, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 20, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 21, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 22, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 23, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 24, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 25, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 26, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 27, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 28, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 29, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 30, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 31, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 32, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 33, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 34, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 35, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 36, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 37, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 38, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 39, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 40, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 41, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 42, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 43, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 44, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 45, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 46, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 47, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 48, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 49, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 50, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 51, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 52, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 53, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 54, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (7, 55, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 1, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 2, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 3, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 4, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 5, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 6, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 7, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 8, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 9, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 10, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 11, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 12, 20)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 13, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 14, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 15, 20)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 16, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 17, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 18, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 19, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 20, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 21, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 22, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 23, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 24, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 25, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 26, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 27, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 28, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 29, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 30, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 31, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 32, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 33, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 34, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 35, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 36, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 37, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 38, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 39, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 40, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 41, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 42, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 43, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 44, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 45, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 46, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 47, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 48, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 49, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 50, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 51, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 52, 20)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 53, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 54, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (8, 55, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 1, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 2, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 3, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 4, 20)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 5, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 6, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 7, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 8, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 9, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 10, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 11, 5)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 12, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 13, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 14, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 15, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 16, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 17, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 18, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 19, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 20, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 21, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 22, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 23, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 24, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 25, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 26, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 27, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 28, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 29, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 30, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 31, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 32, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 33, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 34, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 35, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 36, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 37, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 38, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 39, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 40, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 41, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 42, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 43, 20)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 44, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 45, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 46, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 47, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 48, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 49, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 50, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 51, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 52, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 53, 7)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 54, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (9, 55, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 1, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 2, 14)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 3, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 4, 16)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 5, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 6, 23)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 7, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 8, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 9, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 10, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 11, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 12, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 13, 27)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 14, 6)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 15, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 16, 20)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 17, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 18, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 19, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 20, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 21, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 22, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 23, 15)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 24, 12)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 25, 21)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 26, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 27, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 28, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 29, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 30, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 31, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 32, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 33, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 34, 28)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 35, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 36, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 37, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 38, 17)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 39, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 40, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 41, 13)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 42, 30)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 43, 8)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 44, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 45, 22)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 46, 9)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 47, 26)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 48, 11)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 49, 29)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 50, 18)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 51, 19)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 52, 24)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 53, 10)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 54, 25)
GO
INSERT [dbo].[ELETiendaProducto] ([CodTienda], [CodProducto], [Saldo]) VALUES (10, 55, 17)
GO
INSERT [dbo].[ELETiendas] ([CodTienda], [Nombre], [Telefono], [Email], [Direccion]) VALUES (1, N'Electronica JyH Alajuela', N'24414516', N'electrostorejyhAlajuela@gmail.com', N'Alajuela, 150 m sur de tienda Llobet')
GO
INSERT [dbo].[ELETiendas] ([CodTienda], [Nombre], [Telefono], [Email], [Direccion]) VALUES (2, N'Electronica JyH Belen', N'48758413', N'electrostorejyhAlajuela@gmail.com', N'Frente al gimnasio municipal')
GO
INSERT [dbo].[ELETiendas] ([CodTienda], [Nombre], [Telefono], [Email], [Direccion]) VALUES (3, N'Electronica JyH City Mall', N'24411875', N'electrostorejyhCityMall@gmail.com', N'2do piso, detras de la zona de comidas')
GO
INSERT [dbo].[ELETiendas] ([CodTienda], [Nombre], [Telefono], [Email], [Direccion]) VALUES (4, N'Electronica JyH Nova Centro', N'26848426', N'electrostorejyhNovaCentro@gmail.com', N'Local #51 del centro comercial Nova Centro')
GO
INSERT [dbo].[ELETiendas] ([CodTienda], [Nombre], [Telefono], [Email], [Direccion]) VALUES (5, N'Electronica JyH Lindora', N'27488461', N'electrostorejyhJyHLindora@gmail.com', N'Frente a antigua Sugef, Calle Principal')
GO
INSERT [dbo].[ELETiendas] ([CodTienda], [Nombre], [Telefono], [Email], [Direccion]) VALUES (6, N'Electronica JyH Moravia', N'21459318', N'electrostorejyhJyHMoravia@gmail.com', N'800 al norte del Plaza Lincoln')
GO
INSERT [dbo].[ELETiendas] ([CodTienda], [Nombre], [Telefono], [Email], [Direccion]) VALUES (7, N'Electronica JyH Heredia Centro', N'23547845', N'electrostorejyhHerediaCentro@gmail.com', N'250m oeste del Estado Eladio Rosabal')
GO
INSERT [dbo].[ELETiendas] ([CodTienda], [Nombre], [Telefono], [Email], [Direccion]) VALUES (8, N'Electronica JyH Cartago ', N'26892473', N'electrostorejyhJyHCartago@gmail.com', N'200m sur de la basílica de Los Angeles')
GO
INSERT [dbo].[ELETiendas] ([CodTienda], [Nombre], [Telefono], [Email], [Direccion]) VALUES (9, N'Electronica JyH Grecia Alajuela', N'29848463', N'electrostorejyhGreciaAlajuela@gmail.com', N'Centro comercial La Primavera')
GO
INSERT [dbo].[ELETiendas] ([CodTienda], [Nombre], [Telefono], [Email], [Direccion]) VALUES (10, N'Electronica JyH Tibas', N'24748421', N'electrostorejyhJyHTibas@gmail.com', N'100 al sur del parque central')
GO
/****** Object:  Index [CodCargo_UNIQUE]    Script Date: 03/11/2024 01:04:07 a. m. ******/
ALTER TABLE [dbo].[ELECargos] ADD  CONSTRAINT [CodCargo_UNIQUE] UNIQUE NONCLUSTERED 
(
	[CodCargo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [CodCliente_UNIQUE]    Script Date: 03/11/2024 01:04:07 a. m. ******/
ALTER TABLE [dbo].[ELEClientes] ADD  CONSTRAINT [CodCliente_UNIQUE] UNIQUE NONCLUSTERED 
(
	[CodCliente] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [CodEmpleado_UNIQUE]    Script Date: 03/11/2024 01:04:07 a. m. ******/
ALTER TABLE [dbo].[ELEEmpleados] ADD  CONSTRAINT [CodEmpleado_UNIQUE] UNIQUE NONCLUSTERED 
(
	[CodEmpleado] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [NumFactura_UNIQUE]    Script Date: 03/11/2024 01:04:07 a. m. ******/
ALTER TABLE [dbo].[ELEFacturaEnc] ADD  CONSTRAINT [NumFactura_UNIQUE] UNIQUE NONCLUSTERED 
(
	[NumFactura] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [CodProducto_UNIQUE]    Script Date: 03/11/2024 01:04:07 a. m. ******/
ALTER TABLE [dbo].[ELEProductos] ADD  CONSTRAINT [CodProducto_UNIQUE] UNIQUE NONCLUSTERED 
(
	[CodProducto] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [CodTienda_UNIQUE]    Script Date: 03/11/2024 01:04:07 a. m. ******/
ALTER TABLE [dbo].[ELETiendas] ADD  CONSTRAINT [CodTienda_UNIQUE] UNIQUE NONCLUSTERED 
(
	[CodTienda] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ELEEmpleados]  WITH NOCHECK ADD  CONSTRAINT [fk_ELEEmpleados_ELECargos1] FOREIGN KEY([CodCargo])
REFERENCES [dbo].[ELECargos] ([CodCargo])
GO
ALTER TABLE [dbo].[ELEEmpleados] CHECK CONSTRAINT [fk_ELEEmpleados_ELECargos1]
GO
ALTER TABLE [dbo].[ELEEmpleados]  WITH NOCHECK ADD  CONSTRAINT [fk_ELEEmpleados_ELETiendas] FOREIGN KEY([CodTienda])
REFERENCES [dbo].[ELETiendas] ([CodTienda])
GO
ALTER TABLE [dbo].[ELEEmpleados] CHECK CONSTRAINT [fk_ELEEmpleados_ELETiendas]
GO
ALTER TABLE [dbo].[ELEFacturaEnc]  WITH NOCHECK ADD  CONSTRAINT [fk_ELEFacturaEnc_ELEClientes1] FOREIGN KEY([CodCliente])
REFERENCES [dbo].[ELEClientes] ([CodCliente])
GO
ALTER TABLE [dbo].[ELEFacturaEnc] CHECK CONSTRAINT [fk_ELEFacturaEnc_ELEClientes1]
GO
ALTER TABLE [dbo].[ELEFacturaEnc]  WITH NOCHECK ADD  CONSTRAINT [fk_ELEFacturaEnc_ELEEmpleados1] FOREIGN KEY([CodEmpleado])
REFERENCES [dbo].[ELEEmpleados] ([CodEmpleado])
GO
ALTER TABLE [dbo].[ELEFacturaEnc] CHECK CONSTRAINT [fk_ELEFacturaEnc_ELEEmpleados1]
GO
ALTER TABLE [dbo].[ELEFacturaEnc]  WITH NOCHECK ADD  CONSTRAINT [fk_ELEFacturaEnc_ELETiendas1] FOREIGN KEY([CodTienda])
REFERENCES [dbo].[ELETiendas] ([CodTienda])
GO
ALTER TABLE [dbo].[ELEFacturaEnc] CHECK CONSTRAINT [fk_ELEFacturaEnc_ELETiendas1]
GO
ALTER TABLE [dbo].[ELEFacturasDet]  WITH NOCHECK ADD  CONSTRAINT [fk_ELEFacturasDet_ELEFacturaEnc1] FOREIGN KEY([NumFactura])
REFERENCES [dbo].[ELEFacturaEnc] ([NumFactura])
GO
ALTER TABLE [dbo].[ELEFacturasDet] CHECK CONSTRAINT [fk_ELEFacturasDet_ELEFacturaEnc1]
GO
ALTER TABLE [dbo].[ELEFacturasDet]  WITH NOCHECK ADD  CONSTRAINT [fk_ELEFacturasDet_ELEProductos1] FOREIGN KEY([CodProducto])
REFERENCES [dbo].[ELEProductos] ([CodProducto])
GO
ALTER TABLE [dbo].[ELEFacturasDet] CHECK CONSTRAINT [fk_ELEFacturasDet_ELEProductos1]
GO
ALTER TABLE [dbo].[ELEProductos]  WITH NOCHECK ADD  CONSTRAINT [fk_ELEProductos_ELECategorias1] FOREIGN KEY([CodCategoria])
REFERENCES [dbo].[ELECategorias] ([CodCategoria])
GO
ALTER TABLE [dbo].[ELEProductos] CHECK CONSTRAINT [fk_ELEProductos_ELECategorias1]
GO
ALTER TABLE [dbo].[ELEProductos]  WITH NOCHECK ADD  CONSTRAINT [fk_ELEProductos_ELEMarcas1] FOREIGN KEY([CodMarca])
REFERENCES [dbo].[ELEMarcas] ([CodMarca])
GO
ALTER TABLE [dbo].[ELEProductos] CHECK CONSTRAINT [fk_ELEProductos_ELEMarcas1]
GO
ALTER TABLE [dbo].[ELETiendaProducto]  WITH NOCHECK ADD  CONSTRAINT [CodProducto] FOREIGN KEY([CodProducto])
REFERENCES [dbo].[ELEProductos] ([CodProducto])
GO
ALTER TABLE [dbo].[ELETiendaProducto] CHECK CONSTRAINT [CodProducto]
GO
ALTER TABLE [dbo].[ELETiendaProducto]  WITH NOCHECK ADD  CONSTRAINT [CodTienda] FOREIGN KEY([CodTienda])
REFERENCES [dbo].[ELETiendas] ([CodTienda])
GO
ALTER TABLE [dbo].[ELETiendaProducto] CHECK CONSTRAINT [CodTienda]

