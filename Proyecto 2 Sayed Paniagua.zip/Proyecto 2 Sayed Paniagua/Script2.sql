SELECT Nombre FROM ELEEmpleados;
SELECT NumFactura FROM ELEFacturaEnc;
SELECT FecEntrega FROM ELEFacturaEnc;
SELECT Total FROM ELEFacturaEnc;
SELECT Estado FROM ELEFacturaEnc;
SELECT Nombre FROM ELEClientes;
SELECT Cantidad FROM ELEFacturasDet;
SELECT PrecioUnitario FROM ELEFacturasDet;