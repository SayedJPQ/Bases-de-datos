/* =========================================================
TechServicesCR - Proyecto 1 (MySQL)

MODIFICACIONES
  J.Villalobos  17.Feb.2026  Creación

NOTAS
- Se usa INT como llave primaria por diferentes razones:
  + Rendimiento: un INT utiliza 4 bytes y VARCHAR(100) podría ocupar más de 100. Indices más pequeños, búsquedas más rápidas
  + Integridad referencial: es más limpio tener un FK que sea un número a un texto
  + Portabilidad entre motores de bases de datos
  + Los nombres pueden cambiar (Departamento de TI / Departamento de Tecnologías de Información) sin afectar la llave primaria
  
- No se utiliza ENUM, se maneja un catálogo de estados pues ENUM es propio de MySQL
*/

Select Version();
-- Se trabajara el proyecto 4 en base de la estructura del solucionario. Sin embargo se utilizara tambien los datos que se utilizaron
-- en proyectos anteriores para validar las vistas que se crearan en este proyecto
DROP DATABASE IF EXISTS TechServicesCR;
CREATE DATABASE IF NOT EXISTS TechServicesCR;
USE TechServicesCR;


-- Creamos las tablas en esta seccion

CREATE TABLE Departamento(
 id_departamento INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(50)
);

CREATE TABLE Especialidad(
 id_especialidad INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(50)
);

CREATE TABLE Ubicacion(
 id_ubicacion INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(50)
);

CREATE TABLE Estado(
 id_estado INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(50)
);

CREATE TABLE Tabla_Funcionarios(
 id_usuario INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(50),
 telefono VARCHAR(50),
 email VARCHAR(50),
 id_departamento INT,
 FOREIGN KEY(id_departamento) REFERENCES Departamento(id_departamento)
);

CREATE TABLE Tecnicos(
 id_tecnico INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(50),
 telefono VARCHAR(50),
 email VARCHAR(50),
 id_especialidad INT,
 FOREIGN KEY(id_especialidad) REFERENCES Especialidad(id_especialidad)
);

CREATE TABLE Equipos(
 id_equipo INT AUTO_INCREMENT PRIMARY KEY,
 tipo VARCHAR(50),
 numero_serie VARCHAR(50),
 id_ubicacion INT,
 FOREIGN KEY(id_ubicacion) REFERENCES Ubicacion(id_ubicacion)
);

CREATE TABLE Orden_Servicio(
 id_orden INT AUTO_INCREMENT PRIMARY KEY,
 descripcion TEXT,
 fecha_creacion DATETIME,
 fecha_finalizado DATETIME,
 id_usuario INT,
 id_equipo INT,
 id_estado INT,
 FOREIGN KEY(id_usuario) REFERENCES Tabla_Funcionarios(id_usuario),
 FOREIGN KEY(id_equipo) REFERENCES Equipos(id_equipo),
 FOREIGN KEY(id_estado) REFERENCES Estado(id_estado)
);

CREATE TABLE Orden_Tecnico(
 id_orden INT,
 id_tecnico INT,
 PRIMARY KEY(id_orden,id_tecnico),
 FOREIGN KEY(id_orden) REFERENCES Orden_Servicio(id_orden),
 FOREIGN KEY(id_tecnico) REFERENCES Tecnicos(id_tecnico)
);

CREATE TABLE Historia_Ordenes(
 id_historial INT AUTO_INCREMENT PRIMARY KEY,
 id_orden INT,
 id_tecnico INT,
 fecha_actualizacion DATETIME,
 descripcion TEXT,
 FOREIGN KEY(id_orden) REFERENCES Orden_Servicio(id_orden),
 FOREIGN KEY(id_tecnico) REFERENCES Tecnicos(id_tecnico)
);

SET FOREIGN_KEY_CHECKS = 0;

SET FOREIGN_KEY_CHECKS = 1;
INSERT INTO Estado(nombre) VALUES
('Pendiente'),
('En proceso'),
('Finalizado');

-- Insertamos los datos para validar las vistas, funciones y procedimientos que estaremos utilizando

INSERT INTO Departamento(nombre) VALUES
('TI'),('Administración');

INSERT INTO Especialidad(nombre) VALUES
('Redes'),('Software');

INSERT INTO Ubicacion(nombre) VALUES
('Central'),('Sucursal');

INSERT INTO Tabla_Funcionarios(nombre,telefono,email,id_departamento)
VALUES
('Carlos','8888','carlos@mail.com',1),
('Ana','9999','ana@mail.com',2);

INSERT INTO Tecnicos(nombre,telefono,email,id_especialidad)
VALUES
('Luis','7777','luis@mail.com',1),
('Maria','6666','maria@mail.com',2);

INSERT INTO Equipos(tipo,numero_serie,id_ubicacion)
VALUES
('Laptop','ABC123',1),
('Servidor','XYZ789',2);

INSERT INTO Orden_Servicio(descripcion,fecha_creacion,fecha_finalizado,id_usuario,id_equipo,id_estado)
VALUES
('Error sistema','2026-03-01',NULL,1,1,1),
('Instalar software','2026-03-02','2026-03-03',2,2,2);

INSERT INTO Orden_Tecnico VALUES
(1,1),
(2,2);

INSERT INTO Historia_Ordenes(id_orden,id_tecnico,fecha_actualizacion,descripcion)
VALUES
(1,1,'2026-03-01','Creación orden'),
(2,2,'2026-03-02','Inicio trabajo');

-- =========================================
-- REQUERIMIENTO 1: VISTA
-- =========================================

DROP VIEW IF EXISTS vw_OrdenesDetalle;

CREATE VIEW vw_OrdenesDetalle AS
SELECT 
    o.id_orden,
    o.descripcion,
    o.fecha_creacion,
    o.fecha_finalizado,
    e.nombre AS estado,

    u.id_usuario,
    u.nombre AS nombre_usuario,
    d.nombre AS departamento,

    eq.id_equipo,
    eq.tipo,
    eq.numero_serie,

    t.id_tecnico,
    t.nombre AS nombre_tecnico

FROM Orden_Servicio o
JOIN Estado e ON o.id_estado = e.id_estado
JOIN Tabla_Funcionarios u ON o.id_usuario = u.id_usuario
JOIN Departamento d ON u.id_departamento = d.id_departamento
JOIN Equipos eq ON o.id_equipo = eq.id_equipo
LEFT JOIN Orden_Tecnico ot ON o.id_orden = ot.id_orden
LEFT JOIN Tecnicos t ON ot.id_tecnico = t.id_tecnico;

-- Comprobacion Requerimiento 1 por medio de consulta Select

-- Por estado
SELECT * FROM vw_OrdenesDetalle WHERE estado = 'Pendiente';

-- Por departamento
SELECT * FROM vw_OrdenesDetalle WHERE departamento = 'Administracion';

-- =========================================
-- REQUERIMIENTO 2: TRIGGER
-- =========================================

DROP TRIGGER IF EXISTS trg_AuditoriaOrden;

DELIMITER $$

-- Creacion del Trigger automatico al actualizar el estado
CREATE TRIGGER trg_AuditoriaOrden
AFTER UPDATE ON Orden_Servicio
FOR EACH ROW
BEGIN
    IF OLD.id_estado <> NEW.id_estado THEN
        INSERT INTO Historia_Ordenes(
            id_orden,
            fecha_actualizacion,
            descripcion
        )
        VALUES(
            NEW.id_orden,
            NOW(),
            CONCAT(
                'Estado cambiado de ',
                (SELECT nombre FROM Estado WHERE id_estado = OLD.id_estado),
                ' a ',
                (SELECT nombre FROM Estado WHERE id_estado = NEW.id_estado),
                ' por ',
                CURRENT_USER()
            )
        );
    END IF;
END $$

DELIMITER ;

UPDATE Orden_Servicio
SET id_estado = 2
WHERE id_orden = 1;

SELECT * FROM Historia_Ordenes;

-- =========================================
-- REQUERIMIENTO 3: TRANSACCION
-- =========================================

-- Se modifica procedimiento de crear orden del proyecto 3 para implementar y adaptar para transacciones

DROP PROCEDURE IF EXISTS pr_CrearOrden;

DELIMITER $$

CREATE PROCEDURE pr_CrearOrden(
    IN p_id_usuario INT,
    IN p_descripcion TEXT,
    IN p_id_tecnico INT,
    IN p_id_equipo INT
)
BEGIN
    DECLARE v_id_orden INT;

    START TRANSACTION;

    INSERT INTO Orden_Servicio(
        descripcion,
        fecha_creacion,
        id_usuario,
        id_equipo,
        id_estado
    )
    VALUES (
        p_descripcion,
        NOW(),
        p_id_usuario,
        p_id_equipo,
        1
    );

-- Se verifica la ultima insercion realizada
    SET v_id_orden = LAST_INSERT_ID();

-- Control de errores y rollback si no existe el registro
    IF NOT EXISTS (
        SELECT 1 FROM Tecnicos WHERE id_tecnico = p_id_tecnico
    ) THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Tecnico no existe. Se procede con Rollback';
    END IF;

-- Si existe el registro entonces se realiza Commit
    INSERT INTO Orden_Tecnico(id_orden, id_tecnico)
    VALUES (v_id_orden, p_id_tecnico);

    COMMIT;
END $$
DELIMITER ;

-- Caso correcto
CALL pr_CrearOrden(1,'Nueva orden',1,1);

-- Caso con error
-- CALL pr_CrearOrden(1,'Error',999,1); 
-- Comento esta linea, ya que como los requerimientos se solicita ejecutar en orden 
-- entonces el error no permite continuar con los otros requerimientos. En este caso para validar esta instruccion eliminar
-- los guiones de comentarios

-- =========================================
-- REQUERIMIENTO 4: USUARIOS
-- =========================================

-- Create user crea los usuarios que ingresaran a la base de datos
-- Grant provee los permisos que ejecutaran los usuarios

DROP USER IF EXISTS 'admin_techservices'@'localhost';
DROP USER IF EXISTS 'tecnico_ro'@'localhost';
DROP USER IF EXISTS 'app_techservices'@'localhost';

CREATE USER 'admin_techservices'@'localhost' IDENTIFIED BY 'Proyecto2026*';
GRANT ALL PRIVILEGES ON TechServicesCR.* TO 'admin_techservices'@'localhost';

CREATE USER 'tecnico_ro'@'localhost' IDENTIFIED BY 'Proyecto2026*';
GRANT SELECT ON TechServicesCR.Orden_Servicio TO 'tecnico_ro'@'localhost';
GRANT SELECT ON TechServicesCR.Historia_Ordenes TO 'tecnico_ro'@'localhost';
GRANT SELECT ON TechServicesCR.Equipos TO 'tecnico_ro'@'localhost';
GRANT SELECT ON TechServicesCR.Orden_Tecnico TO 'tecnico_ro'@'localhost';

CREATE USER 'app_techservices'@'localhost' IDENTIFIED BY 'Proyecto2026*';
GRANT SELECT, INSERT, UPDATE ON TechServicesCR.Orden_Servicio TO 'app_techservices'@'localhost';
GRANT SELECT, INSERT, UPDATE ON TechServicesCR.Orden_Tecnico TO 'app_techservices'@'localhost';
GRANT SELECT, INSERT, UPDATE ON TechServicesCR.Historia_Ordenes TO 'app_techservices'@'localhost';

-- =========================================
-- REQUERIMIENTO 5: INDICES
-- =========================================

-- Antes de crear indices con Index
EXPLAIN
SELECT * 
FROM Orden_Servicio
WHERE fecha_creacion >= '2026-01-01'
AND fecha_creacion < '2026-04-01';

-- Crear indices Índices
CREATE INDEX idx_fecha ON Orden_Servicio(fecha_creacion);
CREATE INDEX idx_fecha_usuario ON Orden_Servicio(fecha_creacion, id_usuario);

-- Después de crear indices
EXPLAIN
SELECT * 
FROM Orden_Servicio
WHERE fecha_creacion >= '2026-01-01'
AND fecha_creacion < '2026-04-01';

-- =========================================
-- REQUERIMIENTO 6: ESCENARIO COMPLETO
-- =========================================

-- Para este requerimiento se solicita utilizar todos los requerimientos que hemos observado. En este caso es bajo un escenario practico
-- de como aplicar las vistas, triggers y 

-- Crear orden (Primer requerimiento)
CALL pr_CrearOrden(1,'Laptop no enciende',1,1);

-- Ver historial (trigger) (Segundo Requerimiento)
SELECT * FROM Historia_Ordenes;

-- Cambiar estado 
UPDATE Orden_Servicio
SET id_estado = 2
WHERE id_orden = 3;

-- Consultar vista (Comprobacion primer requerimiento)
SELECT * FROM vw_OrdenesDetalle WHERE id_orden = 3;

-- EXPLAIN (Quinto requermiento)
EXPLAIN SELECT * FROM vw_OrdenesDetalle WHERE id_orden = 3;